# 🦅 ARGUS Guard - Acceptance Test
# argus_guard:exempt-all
#
# 12 AT (Acceptance Test) + 통합 테스트
# 외부 의존 없이 unittest 표준 라이브러리만 사용

import sys
import os
import tempfile
import unittest
import zipfile
from pathlib import Path

# argus_guard 모듈 경로 추가
sys.path.insert(0, str(Path(__file__).parent.parent))

from argus_guard import Guard
from argus_guard.rules import BANNED_TERMS


class TestAcceptance(unittest.TestCase):
    """광범위 포괄 하니스 Acceptance Test 12건."""

    def setUp(self):
        self.g_default = Guard(profile="default")
        self.g_response = Guard(profile="response")
        self.g_reg      = Guard(profile="reg")
        self.g_engine   = Guard(profile="engine")

    # ─────────────────────────────────────────────────────────────
    # AT-1 : 금지어 3종 (P0)
    # ─────────────────────────────────────────────────────────────
    def test_AT_1_banned_terms_p0(self):
        """금지어 3종 (본질 baseline / 결정적 baseline / 정합 baseline) 발견 시 P0 FAIL."""
        for term in BANNED_TERMS:
            text = f"본 결정은 {term}을 따른다."
            result = self.g_response.scan_text(text)
            self.assertEqual(result.status, "FAIL", f"금지어 '{term}' 미검출")
            self.assertGreater(result.summary["P0"], 0, f"P0 위반 보고 없음: {term}")
            # rule_id 검증
            p0_rules = [v.rule_id for v in result.violations if v.severity == "P0"]
            self.assertIn("P0_BANNED_TERMS", p0_rules)

    # ─────────────────────────────────────────────────────────────
    # AT-2 : 한자 검출 (P0)
    # ─────────────────────────────────────────────────────────────
    def test_AT_2_cjk_p0(self):
        """한자 발견 시 P0 FAIL."""
        text = "본 사안은 重要한 결정입니다."  # '重要' = 한자
        result = self.g_response.scan_text(text)
        self.assertEqual(result.status, "FAIL")
        self.assertGreater(result.summary["P0"], 0)
        rules = [v.rule_id for v in result.violations]
        self.assertIn("P0_CJK_CHARS", rules)

    # ─────────────────────────────────────────────────────────────
    # AT-3 : 정상 한국어 (PASS)
    # ─────────────────────────────────────────────────────────────
    def test_AT_3_normal_korean_pass(self):
        """정상 한국어 문장 + 금지어 없음 → PASS."""
        text = (
            "🎯 결론 우선: 본 결정은 RULE 29 v2 PASS에 따라 채택합니다.\n"
            "⏱️ 약 5분 소요 예상.\n"
            "Sharpe +0.123 / CAGR +1.45p / MDD -2.34p 정량 근거 확인.\n"
            "근거 기준 (LIVE 운영)을 따라 진행."
        )
        result = self.g_response.scan_text(text)
        # P0 / P1 없으면 PASS
        self.assertEqual(result.summary["P0"], 0)
        self.assertEqual(result.summary["P1"], 0)

    # ─────────────────────────────────────────────────────────────
    # AT-4 : Python 주석 내 금지어
    # ─────────────────────────────────────────────────────────────
    def test_AT_4_banned_in_python_comment_p0(self):
        """Python 주석 내 금지어 발견 시 P0 FAIL."""
        text = '# 본 함수는 본질 baseline에 따라 계산\ndef f(): return 0\n'
        with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False, encoding="utf-8") as f:
            f.write(text)
            tmp_path = f.name
        try:
            result = self.g_default.scan_file(tmp_path)
            self.assertEqual(result.status, "FAIL")
            self.assertGreater(result.summary["P0"], 0)
        finally:
            os.unlink(tmp_path)

    # ─────────────────────────────────────────────────────────────
    # AT-5 : Markdown 표 안 금지어
    # ─────────────────────────────────────────────────────────────
    def test_AT_5_banned_in_markdown_table_p0(self):
        """Markdown 표 안에 금지어 발견 시 P0 FAIL."""
        text = "| 항목 | 결과 |\n|:--|:--|\n| 본질 baseline | OK |\n"
        result = self.g_default.scan_text(text)
        self.assertEqual(result.status, "FAIL")
        self.assertGreater(result.summary["P0"], 0)

    # ─────────────────────────────────────────────────────────────
    # AT-6 : zip 내부 파일 위반
    # ─────────────────────────────────────────────────────────────
    def test_AT_6_zip_internal_violation_p0(self):
        """zip 내부 파일에 금지어 발견 시 P0 FAIL."""
        with tempfile.NamedTemporaryFile(suffix=".zip", delete=False) as f:
            tmp_zip = f.name
        try:
            with zipfile.ZipFile(tmp_zip, "w") as zf:
                zf.writestr("docs/decision.md", "결정적 baseline 채택.")
                zf.writestr("docs/clean.md", "Sharpe +0.123 / CAGR +1.45p")
            result = self.g_default.scan_zip(tmp_zip)
            self.assertEqual(result.status, "FAIL")
            self.assertGreater(result.summary["P0"], 0)
            # zip 내부 경로 정합
            files = [v.file for v in result.violations if v.file]
            self.assertTrue(any("decision.md" in f for f in files))
        finally:
            os.unlink(tmp_zip)

    # ─────────────────────────────────────────────────────────────
    # AT-7 : NO-GO 보고서에 9point 누락
    # ─────────────────────────────────────────────────────────────
    def test_AT_7_no_go_9point_missing_p1(self):
        """NO-GO 결정 발견 + 9-point 키워드 5건 이상 누락 시 P1."""
        text = (
            "본 후보는 NO-GO 처리한다.\n"
            "Phase A t=-3.5로 t-stat 음수 검출.\n"
            "Sharpe -0.05 / MDD -0.5p\n"
        )
        result = self.g_reg.scan_text(text)
        # 9point 누락 보고
        rules = [v.rule_id for v in result.violations]
        self.assertIn("P1_NO_GO_9POINT_MISSING", rules)

    # ─────────────────────────────────────────────────────────────
    # AT-8 : Signal GO + Capital NO-GO 분리 (PASS)
    # ─────────────────────────────────────────────────────────────
    def test_AT_8_signal_capital_split_pass(self):
        """Signal Layer GO + Capital Allocation 보류 분리 → P1_SIGNAL_CAPITAL_BAD 미발동."""
        text = (
            "🎯 결론: CAND-S121_β Tier 1 Signal Layer 채택 (Capital Level 1).\n"
            "Phase A α +14.52p / t=+4.21 정량 근거.\n"
            "Signal Layer: GO / Capital Allocation: 보류 (sleeve cap 不요)\n"
            "격언 #118 v3 + #119 v2 + #120 v1 정합.\n"
            "분포 평균/중앙값/std/분위 동시 보고.\n"
            "Top5 진입률 0% / 평균 rank 18.5위 / shadow forward return / hit rate / payoff 측정.\n"
            "regime 분기 P1/P2/MID 모두 검증.\n"
            "outlier 진단 + 대상 확장 + 양방향 모두 PASS.\n"
            "sub-group + 대안 자산 + 꼬리 모두 점검.\n"
        )
        result = self.g_reg.scan_text(text)
        rules = [v.rule_id for v in result.violations]
        self.assertNotIn("P1_SIGNAL_CAPITAL_BAD", rules)

    # ─────────────────────────────────────────────────────────────
    # AT-9 : Top5 진입률 0인데 signal 폐기
    # ─────────────────────────────────────────────────────────────
    def test_AT_9_participation_bias_fail_p1(self):
        """Top5 진입률 0 + signal 폐기 표현 → P1 FAIL."""
        text = "Top5 0% 진입 → 신호 실패. 폐기 처리."
        result = self.g_reg.scan_text(text)
        self.assertEqual(result.status, "FAIL")

    # ─────────────────────────────────────────────────────────────
    # AT-10 : Crown 닫힌 표현
    # ─────────────────────────────────────────────────────────────
    def test_AT_10_crown_closed_p1(self):
        """'Crown #68 완전 폐기' → P1 FAIL."""
        text = "Crown #68 완전 폐기 결정."
        result = self.g_reg.scan_text(text)
        rules = [v.rule_id for v in result.violations]
        self.assertIn("P1_CROWN_CLOSED", rules)

    # ─────────────────────────────────────────────────────────────
    # AT-11 : Style v1.2 카운트 초과
    # ─────────────────────────────────────────────────────────────
    def test_AT_11_style_v12_count_p1(self):
        """'baseline' 6회 사용 (limit=5) → P1 FAIL."""
        text = "baseline 1, baseline 2, baseline 3, baseline 4, baseline 5, baseline 6"
        result = self.g_response.scan_text(text)
        rules = [v.rule_id for v in result.violations]
        self.assertIn("P1_BASELINE_OVERUSE", rules)

    # ─────────────────────────────────────────────────────────────
    # AT-12 : ENTRY_THRESHOLD split (Crown #65 NO-GO 영구 회피)
    # ─────────────────────────────────────────────────────────────
    def test_AT_12_entry_threshold_split_p1(self):
        """ENTRY_THRESHOLD dict 사용 + hard-coded return s > N 잔존 → P1 FAIL."""
        text = (
            "ENTRY_THRESHOLD = {'XLU': 1.5, 'TLT': 1.0}\n\n"
            "def entry_TLT(m, m1, m3):\n"
            "    s = 5.0\n"
            "    return s > 1.0, max(s, 0)\n"  # hard-coded
        )
        with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False, encoding="utf-8") as f:
            f.write(text)
            f.write("\nclass PRIMA_engine: pass\n")  # 엔진 인식 트리거
            tmp_path = f.name
        try:
            result = self.g_engine.scan_file(tmp_path)
            rules = [v.rule_id for v in result.violations]
            self.assertIn("P1_ENTRY_THRESHOLD_SPLIT", rules)
        finally:
            os.unlink(tmp_path)


class TestIntegration(unittest.TestCase):
    """통합 테스트."""

    def test_all_profiles_load(self):
        """모든 프로필 인스턴스화 가능."""
        from argus_guard.profiles import PROFILES
        for name in PROFILES:
            g = Guard(profile=name)
            self.assertIsNotNone(g)

    def test_empty_text_pass(self):
        """빈 텍스트 PASS."""
        g = Guard(profile="response")
        result = g.scan_text("")
        self.assertEqual(result.summary["P0"], 0)
        self.assertEqual(result.summary["P1"], 0)

    def test_report_formats(self):
        """JSON / Markdown 형식 출력 가능."""
        g = Guard(profile="response")
        result = g.scan_text("결정적 baseline 사용.")
        j = result.to_json()
        m = result.to_markdown()
        self.assertIn("P0_BANNED_TERMS", j)
        self.assertIn("P0", m)


class TestV101Additions(unittest.TestCase):
    """v1.0.1 신규 룰 8개 Acceptance Test."""

    def setUp(self):
        self.g_response = Guard(profile="response")
        self.g_reg      = Guard(profile="reg")
        self.g_engine   = Guard(profile="engine")

    # AT-13: P1_DATA_FABRICATION
    def test_AT_13_data_fabrication_p1(self):
        """'대략 +5%' 추정값 미명시 → P1 FAIL."""
        text = "수익률은 대략 +5%로 예상됨."  # 추정 표기 없음
        result = self.g_response.scan_text(text)
        rules = [v.rule_id for v in result.violations]
        self.assertIn("P1_DATA_FABRICATION", rules)

    # AT-13b: 추정 표기 있으면 PASS
    def test_AT_13b_data_fabrication_with_estimate_pass(self):
        """'대략 +5% (추정)' → P1_DATA_FABRICATION 미발동."""
        text = "수익률은 대략 +5% (추정)로 예상됨."
        result = self.g_response.scan_text(text)
        rules = [v.rule_id for v in result.violations]
        self.assertNotIn("P1_DATA_FABRICATION", rules)

    # AT-14: P1_BUNDLE_SPLIT
    def test_AT_14_bundle_split_p1(self):
        """'세부는 다음 응답' → P1 FAIL."""
        text = "본 결정 일부만 처리. 세부는 다음 응답에 진행."
        result = self.g_reg.scan_text(text)
        rules = [v.rule_id for v in result.violations]
        self.assertIn("P1_BUNDLE_SPLIT", rules)

    # AT-15: P1_AXIOM_OVERUSE
    def test_AT_15_axiom_overuse_p1(self):
        """unique 격언 인용 >5건 → P1 FAIL."""
        text = (
            "본 결정은 격언 #15, 격언 #25, 격언 #52, 격언 #75, "
            "격언 #97, 격언 #118, 격언 #120 7건 정합."
        )
        result = self.g_response.scan_text(text)
        rules = [v.rule_id for v in result.violations]
        self.assertIn("P1_AXIOM_OVERUSE", rules)

    # AT-16: P1_VERSION_NO_DIFF
    def test_AT_16_version_no_diff_p1(self):
        """'v8.9.37 → v8.9.38' + V-Diff 없음 → P1 FAIL."""
        text = "briefing v8.9.37 → v8.9.38 갱신 완료."
        # V-Diff 패턴 없음
        result = self.g_engine.scan_text(text)
        rules = [v.rule_id for v in result.violations]
        self.assertIn("P1_VERSION_NO_DIFF", rules)

    # AT-16b: V-Diff 있으면 PASS
    def test_AT_16b_version_with_diff_pass(self):
        """버전 변경 + ➕➖✏️ V-Diff → PASS."""
        text = (
            "briefing v8.9.37 → v8.9.38 갱신.\n"
            "➕ 추가: detect_decision_drivers 함수\n"
            "✏️ 변경: Embed 4 길이 처방"
        )
        result = self.g_engine.scan_text(text)
        rules = [v.rule_id for v in result.violations]
        self.assertNotIn("P1_VERSION_NO_DIFF", rules)

    # AT-17: P1_EXSN_PREEVAL_MISSING
    def test_AT_17_exsn_preeval_missing_p1(self):
        """'채택 결정' + ExSn 사전 평가 누락 → P1 FAIL."""
        text = "본 후보 채택 결정. CAGR +1.5p 정량 근거 확인."
        result = self.g_reg.scan_text(text)
        rules = [v.rule_id for v in result.violations]
        self.assertIn("P1_EXSN_PREEVAL_MISSING", rules)

    # AT-18: P1_SINGLE_ASSET_BOOST
    def test_AT_18_single_asset_boost_p1(self):
        """'TLT 100% 채택' + 분산 검증 누락 → P1 FAIL."""
        text = "TLT 100% 채택 결정. Sharpe +1.5 정량 근거."
        result = self.g_engine.scan_text(text)
        rules = [v.rule_id for v in result.violations]
        self.assertIn("P1_SINGLE_ASSET_BOOST", rules)

    # AT-19: P1_DEAD_SOURCE
    def test_AT_19_dead_source_p1(self):
        """'DBnomics ISM/pmi/pm' 사용 → P1 FAIL."""
        text = "데이터 source: DBnomics ISM/pmi/pm 사용."
        result = self.g_engine.scan_text(text)
        rules = [v.rule_id for v in result.violations]
        self.assertIn("P1_DEAD_SOURCE", rules)

    # AT-20: P2_COMMANDER_AUTHORITY_MISSING
    def test_AT_20_commander_authority_missing_p2(self):
        """'채택 결정' + Commander 권한 분리 누락 → P2."""
        text = (
            "후보 채택 결정. CAGR +1.5p 정량 근거.\n"
            "ExSn 사전 평가: T10YIE>2.5 청산 조건 확인.\n"
        )
        result = self.g_reg.scan_text(text)
        rules = [v.rule_id for v in result.violations]
        self.assertIn("P2_COMMANDER_AUTHORITY_MISSING", rules)

    # AT-20b: Commander 권한 분리 명시 시 PASS
    def test_AT_20b_commander_authority_pass(self):
        """Commander 권한 분리 명시 → P2_COMMANDER_AUTHORITY_MISSING 미발동."""
        text = (
            "후보 채택 권고 (PRIMA = 권고 only / Commander = 최종 결정).\n"
            "CAGR +1.5p 정량 근거.\n"
            "ExSn 사전 평가: T10YIE>2.5 청산 조건 확인.\n"
        )
        result = self.g_reg.scan_text(text)
        rules = [v.rule_id for v in result.violations]
        self.assertNotIn("P2_COMMANDER_AUTHORITY_MISSING", rules)


if __name__ == "__main__":
    unittest.main(verbosity=2)
