# 🦅 ARGUS Guard - CLI entry point
# argus_guard:exempt-all
#
# 사용:
#   python -m argus_guard scan-text response.txt
#   python -m argus_guard scan-text - < response.txt   # stdin
#   python -m argus_guard scan-file REG-S122.md --profile reg
#   python -m argus_guard scan-tree ./outputs --recursive
#   python -m argus_guard scan-zip ARGUS_ARCHIVE.zip
#   python -m argus_guard list-profiles
#   python -m argus_guard list-rules

import argparse
import sys
from pathlib import Path

from .core import Guard
from .profiles import PROFILES
from .rules import RULES_REGISTRY


def cmd_scan_text(args) -> int:
    path = args.path
    if path == "-":
        text = sys.stdin.read()
        target_name = "<stdin>"
    else:
        p = Path(path)
        if not p.exists():
            print(f"🚨 파일 없음: {path}", file=sys.stderr)
            return 2
        text = p.read_text(encoding="utf-8")
        target_name = str(p)
    g = Guard(profile=args.profile, verbose=args.verbose)
    result = g.scan_text(text, target_name=target_name)
    _print_result(result, args)
    return _exit_code(result, args)


def cmd_scan_file(args) -> int:
    g = Guard(profile=args.profile, verbose=args.verbose)
    try:
        result = g.scan_file(args.path)
    except (FileNotFoundError, ValueError) as e:
        print(f"🚨 {e}", file=sys.stderr)
        return 2
    _print_result(result, args)
    return _exit_code(result, args)


def cmd_scan_tree(args) -> int:
    g = Guard(profile=args.profile, verbose=args.verbose)
    try:
        result = g.scan_tree(args.path, recursive=args.recursive)
    except (FileNotFoundError, ValueError) as e:
        print(f"🚨 {e}", file=sys.stderr)
        return 2
    _print_result(result, args)
    return _exit_code(result, args)


def cmd_scan_zip(args) -> int:
    g = Guard(profile=args.profile, verbose=args.verbose)
    try:
        result = g.scan_zip(args.path)
    except (FileNotFoundError, ValueError) as e:
        print(f"🚨 {e}", file=sys.stderr)
        return 2
    _print_result(result, args)
    return _exit_code(result, args)


def cmd_list_profiles(args) -> int:
    print("🦅 ARGUS Guard - 등록 프로필 매트릭스")
    print()
    print(f"{'name':<10} {'rules':>5}  description")
    print("-" * 72)
    for name, p in PROFILES.items():
        rules_n = len(p.get("enabled_rules", []))
        print(f"{name:<10} {rules_n:>5}  {p.get('description', '')}")
    return 0


def cmd_list_rules(args) -> int:
    print("🦅 ARGUS Guard - 등록 룰 매트릭스")
    print()
    print(f"{'rule_id':<32} {'sev':<4} {'domain':<14} desc")
    print("-" * 100)
    for rid, info in RULES_REGISTRY.items():
        print(f"{rid:<32} {info['severity']:<4} {info['domain']:<14} {info['desc']}")
    return 0


def _print_result(result, args) -> None:
    fmt = args.format
    if fmt == "json":
        print(result.to_json(indent=2))
    elif fmt == "markdown":
        print(result.to_markdown())
    else:
        # short
        status_icon = "🟢" if result.status == "PASS" else "🚨"
        print(f"{status_icon} ARGUS Guard {result.status}")
        print(f"   target:     {result.target}")
        print(f"   scanned_at: {result.scanned_at}")
        print(f"   summary:    P0={result.summary['P0']} P1={result.summary['P1']} P2={result.summary['P2']} P3={result.summary['P3']}")
        print(f"   sha256:     {result.sha256[:16]}...")
        if result.violations:
            print()
            print("   위반 상세:")
            for v in result.violations[:20]:
                loc = ""
                if v.file:
                    loc = v.file
                    if v.line:
                        loc += f":L{v.line}"
                print(f"   [{v.severity}] {v.rule_id}  {loc}")
                print(f"          {v.message}")
                if v.suggestion:
                    print(f"          → {v.suggestion}")
            if len(result.violations) > 20:
                print(f"   ... ({len(result.violations) - 20}건 생략)")


def _exit_code(result, args) -> int:
    fail_on = []
    if args.fail_on_p0:
        fail_on.append("P0")
    if args.fail_on_p1:
        fail_on.append("P1")
    if args.fail_on_p2:
        fail_on.append("P2")
    if not fail_on:
        fail_on = ["P0", "P1"]
    for sev in fail_on:
        if result.summary.get(sev, 0) > 0:
            return 1
    return 0


def main(argv=None):
    parser = argparse.ArgumentParser(
        prog        = "argus_guard",
        description = "🦅 ARGUS Guard - 광범위 포괄 차단형 검증 계층 v1.0.0",
    )
    parser.add_argument("--profile",      default="default",
                        choices=list(PROFILES.keys()),
                        help="검사 프로필 (default/response/reg/engine/briefing/ssot/handoff)")
    parser.add_argument("--format",       default="short",
                        choices=["short", "json", "markdown"],
                        help="출력 형식")
    parser.add_argument("--fail-on-p0",   action="store_true", default=True,
                        help="P0 발견 시 exit 1 (기본 ON)")
    parser.add_argument("--fail-on-p1",   action="store_true", default=True,
                        help="P1 발견 시 exit 1 (기본 ON)")
    parser.add_argument("--fail-on-p2",   action="store_true", default=False,
                        help="P2 발견 시 exit 1 (기본 OFF)")
    parser.add_argument("--verbose", "-v", action="store_true",
                        help="자세한 출력")

    sub = parser.add_subparsers(dest="cmd", required=True)

    s_text = sub.add_parser("scan-text", help="텍스트 파일 / stdin 검사")
    s_text.add_argument("path", help="파일 경로 또는 '-' (stdin)")
    s_text.set_defaults(func=cmd_scan_text)

    s_file = sub.add_parser("scan-file", help="단일 파일 검사")
    s_file.add_argument("path", help="파일 경로")
    s_file.set_defaults(func=cmd_scan_file)

    s_tree = sub.add_parser("scan-tree", help="디렉토리 재귀 검사")
    s_tree.add_argument("path", help="디렉토리 경로")
    s_tree.add_argument("--recursive", action="store_true", default=True)
    s_tree.set_defaults(func=cmd_scan_tree)

    s_zip = sub.add_parser("scan-zip", help="zip 압축 검사")
    s_zip.add_argument("path", help="zip 파일 경로")
    s_zip.set_defaults(func=cmd_scan_zip)

    sub.add_parser("list-profiles", help="등록 프로필 목록").set_defaults(func=cmd_list_profiles)
    sub.add_parser("list-rules",    help="등록 룰 목록").set_defaults(func=cmd_list_rules)

    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
