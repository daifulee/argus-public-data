# 🦅 ARGUS Guard - 광범위 포괄 차단형 검증 계층 v1.0.0
# argus_guard:exempt-all
#
# Commander Lignas 명령 (2026-05-19): "기존 지속 반복 실수 교정용 광범위 포괄 하니스"
# Style Patch v1.2 + 9-point checklist + 5-Tier Capital Level +
# Top5 참여 편향 + Crown 표현 + Signal/Capital 분리 + §35 누적 학습 통합
#
# 격언 정합: #15 + #20 + #25 + #46 + #52 + #74 + #75 v4 + #79 + #97 v2 + #98 +
#            #106 + #112 v2 #9 v2 + #115 + #116 + #117 + #118 v3 + #119 v2 + #120 v1
# §35 누적: #10 + #11 + #12 + #13 + .NEW_11 + .26
# userPreferences 정합: 한국어 / bold + 이모지 / LIVE 값 🌟 ** ** 🌟 / 풀파일 출력 / 약어 풀이 / 예상 소요

from .core import Guard, GuardResult, Violation
from .rules import RULES_REGISTRY, BANNED_TERMS, STYLE_V12_LIMITS
from .profiles import PROFILES

__version__ = "1.0.1"
__author__ = "Claude (Anthropic Opus 4.7) - ARGUS Commander Lignas 명령"
__all__ = [
    "Guard",
    "GuardResult",
    "Violation",
    "RULES_REGISTRY",
    "BANNED_TERMS",
    "STYLE_V12_LIMITS",
    "PROFILES",
]
