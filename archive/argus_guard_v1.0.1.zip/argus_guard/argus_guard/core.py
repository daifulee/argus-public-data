# 🦅 ARGUS Guard - 메인 차단형 검증 코어
#
# argus_guard:exempt-all
# (본 파일은 patchwork 등 룰 패턴을 코드로 인용하므로 false-positive 회피용 exempt)
#
# Guard 클래스 = 광범위 포괄 하니스 entry point
# Violation = 단일 위반 결과 데이터 구조
# GuardResult = 전체 검사 결과 (위반 누적 + 통계 + sha256)

import hashlib
import json
import re
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import List, Optional, Dict, Any
from datetime import datetime, timezone, timedelta

from .rules import RULES_REGISTRY
from .profiles import PROFILES
from .scanners.text_scanner import TextScanner
from .scanners.logic_scanner import LogicScanner
from .scanners.artifact_scanner import ArtifactScanner
from .scanners.package_scanner import PackageScanner


# ═══════════════════════════════════════════════════════════════════════════
# 데이터 구조
# ═══════════════════════════════════════════════════════════════════════════

@dataclass
class Violation:
    """단일 위반 결과."""
    rule_id:     str                          # 룰 등록 ID (RULES_REGISTRY key)
    severity:    str                          # P0 / P1 / P2 / P3
    domain:      str                          # style_v12 / logic / engine / preferences / language
    file:        Optional[str] = None         # 파일 경로 (텍스트 검사 시 None)
    line:        Optional[int] = None         # 줄 번호 (1-indexed)
    column:      Optional[int] = None         # 열 번호 (1-indexed)
    snippet:     str = ""                     # 위반 영역 텍스트
    message:     str = ""                     # 위반 사유
    suggestion:  str = ""                     # 권장 수정 안
    axiom:       str = ""                     # 격언/§35 참조

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class GuardResult:
    """전체 검사 결과."""
    target:      str                                                                     # 검사 대상 (text/path/zip)
    status:      str = "PASS"                                                            # PASS / FAIL
    violations:  List[Violation] = field(default_factory=list)
    summary:     Dict[str, int] = field(default_factory=lambda: {"P0": 0, "P1": 0, "P2": 0, "P3": 0})
    sha256:      str = ""
    scanned_at:  str = ""
    target_hash: str = ""

    def add(self, v: Violation) -> None:
        self.violations.append(v)
        if v.severity in self.summary:
            self.summary[v.severity] += 1

    def finalize(self, fail_on: Optional[List[str]] = None) -> None:
        """검사 종료 + status 결정."""
        if fail_on is None:
            fail_on = ["P0", "P1"]
        for sev in fail_on:
            if self.summary.get(sev, 0) > 0:
                self.status = "FAIL"
                break
        # KST 시각 (UTC+9)
        kst = timezone(timedelta(hours=9))
        self.scanned_at = datetime.now(kst).strftime("%Y-%m-%d %H:%M:%S KST")
        # 결과 sha256
        payload = json.dumps(
            {
                "target":     self.target,
                "summary":    self.summary,
                "violations": [v.to_dict() for v in self.violations],
            },
            sort_keys=True,
            ensure_ascii=False,
        )
        self.sha256 = hashlib.sha256(payload.encode("utf-8")).hexdigest()

    def to_dict(self) -> Dict[str, Any]:
        return {
            "target":      self.target,
            "status":      self.status,
            "summary":     self.summary,
            "violations":  [v.to_dict() for v in self.violations],
            "sha256":      self.sha256,
            "scanned_at":  self.scanned_at,
            "target_hash": self.target_hash,
        }

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), ensure_ascii=False, indent=indent)

    def to_markdown(self) -> str:
        """Markdown 보고서 형식."""
        lines = ["# 🦅 ARGUS Guard Report", ""]
        lines.append(f"- **target**: `{self.target}`")
        lines.append(f"- **status**: 🌟 **{self.status}** 🌟")
        lines.append(f"- **scanned_at**: {self.scanned_at}")
        lines.append(f"- **sha256**: `{self.sha256[:16]}...`")
        if self.target_hash:
            lines.append(f"- **target_hash**: `{self.target_hash[:16]}...`")
        lines.append("")
        lines.append("## 📊 위반 통계")
        lines.append("")
        lines.append("| 등급 | 건수 |")
        lines.append("|:--:|--:|")
        for sev in ("P0", "P1", "P2", "P3"):
            cnt = self.summary.get(sev, 0)
            mark = "🚨" if cnt > 0 and sev in ("P0", "P1") else ("⚠️" if cnt > 0 else "✅")
            lines.append(f"| {mark} **{sev}** | {cnt} |")
        lines.append("")
        if not self.violations:
            lines.append("## ✅ 위반 없음 (PASS)")
            return "\n".join(lines)
        # 등급별 상세
        by_severity: Dict[str, List[Violation]] = {"P0": [], "P1": [], "P2": [], "P3": []}
        for v in self.violations:
            by_severity.setdefault(v.severity, []).append(v)
        for sev in ("P0", "P1", "P2", "P3"):
            vs = by_severity.get(sev, [])
            if not vs:
                continue
            lines.append(f"## 🚨 {sev} 위반 상세 ({len(vs)}건)")
            lines.append("")
            for i, v in enumerate(vs, 1):
                lines.append(f"### {sev}-{i}: {v.rule_id}")
                lines.append("")
                lines.append(f"- **domain**: {v.domain}")
                if v.file:
                    loc = v.file
                    if v.line:
                        loc += f":L{v.line}"
                        if v.column:
                            loc += f":C{v.column}"
                    lines.append(f"- **location**: `{loc}`")
                if v.snippet:
                    snippet = v.snippet.replace("\n", " ")[:120]
                    lines.append(f"- **snippet**: `{snippet}`")
                lines.append(f"- **message**: {v.message}")
                if v.suggestion:
                    lines.append(f"- **suggestion**: {v.suggestion}")
                if v.axiom:
                    lines.append(f"- **axiom**: {v.axiom}")
                lines.append("")
        return "\n".join(lines)


# ═══════════════════════════════════════════════════════════════════════════
# Guard 메인 클래스
# ═══════════════════════════════════════════════════════════════════════════

class Guard:
    """ARGUS 광범위 포괄 차단형 검증 계층.

    사용:
        g = Guard()
        result = g.scan_text("응답 텍스트")
        result = g.scan_file("path/to/file.md", profile="reg")
        result = g.scan_tree("./outputs")
        result = g.scan_zip("ARGUS_ARCHIVE.zip")
        print(result.to_markdown())
        if result.status == "FAIL":
            exit(1)
    """

    # 텍스트로 인식할 파일 확장자
    TEXT_EXTENSIONS = {
        ".py", ".md", ".txt", ".json", ".yaml", ".yml", ".csv",
        ".rst", ".ini", ".cfg", ".toml", ".sh", ".html",
    }

    # 자기 적용 dogfooding 시 룰 정의 파일이 룰을 매칭하는 것을 회피하기 위한 magic comment.
    # 파일 상단 200줄 안에 다음 directive가 있으면:
    #   # argus_guard:exempt-all     → 전체 검사 제외 (Python/sh)
    #   <!-- argus_guard:exempt-all --> → 전체 검사 제외 (Markdown/HTML)
    #   # argus_guard:exempt=RULE1,RULE2  → 특정 룰만 제외
    EXEMPT_ALL_PATTERN = re.compile(r"(#|<!--)\s*argus_guard\s*:\s*exempt-all\b")
    EXEMPT_SOME_PATTERN = re.compile(r"(#|<!--)\s*argus_guard\s*:\s*exempt\s*=\s*([A-Z0-9_,\s]+)")

    @classmethod
    def _read_exempt_directive(cls, text: str):
        """파일 상단 directive 검사. (is_all_exempt: bool, exempted_rules: set)"""
        head = "\n".join(text.splitlines()[:200])
        if cls.EXEMPT_ALL_PATTERN.search(head):
            return True, set()
        m = cls.EXEMPT_SOME_PATTERN.search(head)
        if m:
            rules = {r.strip() for r in m.group(2).split(",") if r.strip()}
            return False, rules
        return False, set()

    def __init__(self, profile: str = "default", verbose: bool = False):
        self.profile_name = profile
        self.profile      = PROFILES.get(profile, PROFILES["default"])
        self.verbose      = verbose
        self.text_scanner     = TextScanner(self.profile)
        self.logic_scanner    = LogicScanner(self.profile)
        self.artifact_scanner = ArtifactScanner(self.profile)
        self.package_scanner  = PackageScanner(self.profile)

    # ── Text 검사 ──
    def scan_text(self, text: str, target_name: str = "<text>") -> GuardResult:
        """텍스트 (대화 응답) 검사."""
        result = GuardResult(target=target_name)
        # 검사 대상 sha256
        result.target_hash = hashlib.sha256(text.encode("utf-8")).hexdigest()
        # Text 검사 (Style v1.2 + 한자 + LIVE 값 + 약어 + 시간 예상 + 결론 우선 + 번호 목록 + HTML)
        for v in self.text_scanner.scan(text, file_path=None):
            result.add(v)
        # Logic 검사 (9point + Top5 + Crown + Signal/Capital + 평균값 + Phase A + 정량 근거 + 시간 지연 + 블랭킷 + entry/exit + BT 단독 + 미봉책 + era)
        for v in self.logic_scanner.scan(text, file_path=None):
            result.add(v)
        result.finalize(fail_on=self.profile.get("fail_on", ["P0", "P1"]))
        return result

    # ── 단일 파일 검사 ──
    def scan_file(self, path: str, profile: Optional[str] = None) -> GuardResult:
        """단일 파일 검사."""
        p = Path(path)
        if not p.exists():
            raise FileNotFoundError(f"파일 없음: {path}")
        if not p.is_file():
            raise ValueError(f"파일이 아님: {path}")
        if profile and profile in PROFILES:
            # 일시 profile 변경
            tmp_profile = PROFILES[profile]
            text_s = TextScanner(tmp_profile)
            logic_s = LogicScanner(tmp_profile)
            artifact_s = ArtifactScanner(tmp_profile)
        else:
            text_s = self.text_scanner
            logic_s = self.logic_scanner
            artifact_s = self.artifact_scanner
        result = GuardResult(target=str(p))
        if p.suffix.lower() not in self.TEXT_EXTENSIONS:
            # 텍스트 아님 → artifact 메타 검사만
            for v in artifact_s.scan_meta(p):
                result.add(v)
            result.finalize(fail_on=self.profile.get("fail_on", ["P0", "P1"]))
            return result
        # 텍스트 읽기
        try:
            text = p.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            # 비 UTF-8 파일 → meta 검사만
            for v in artifact_s.scan_meta(p):
                result.add(v)
            result.finalize(fail_on=self.profile.get("fail_on", ["P0", "P1"]))
            return result
        result.target_hash = hashlib.sha256(text.encode("utf-8")).hexdigest()
        # ── exempt directive 검사 ──
        is_all_exempt, exempt_rules = self._read_exempt_directive(text)
        if is_all_exempt:
            result.finalize(fail_on=self.profile.get("fail_on", ["P0", "P1"]))
            return result
        for v in text_s.scan(text, file_path=str(p)):
            if v.rule_id in exempt_rules:
                continue
            result.add(v)
        for v in logic_s.scan(text, file_path=str(p)):
            if v.rule_id in exempt_rules:
                continue
            result.add(v)
        for v in artifact_s.scan(text, p):
            if v.rule_id in exempt_rules:
                continue
            result.add(v)
        result.finalize(fail_on=self.profile.get("fail_on", ["P0", "P1"]))
        return result

    # ── 디렉토리 검사 ──
    def scan_tree(self, path: str, recursive: bool = True) -> GuardResult:
        """디렉토리 재귀 검사."""
        p = Path(path)
        if not p.exists():
            raise FileNotFoundError(f"디렉토리 없음: {path}")
        if not p.is_dir():
            raise ValueError(f"디렉토리 아님: {path}")
        result = GuardResult(target=str(p))
        pattern = "**/*" if recursive else "*"
        for sub in sorted(p.glob(pattern)):
            if sub.is_dir():
                continue
            if sub.suffix.lower() not in self.TEXT_EXTENSIONS:
                continue
            try:
                sub_result = self.scan_file(str(sub))
                for v in sub_result.violations:
                    result.add(v)
            except Exception as e:
                # 개별 파일 실패는 경고로 처리 (전체 중단 방지)
                if self.verbose:
                    print(f"⚠️ scan failed: {sub} - {e}")
        result.finalize(fail_on=self.profile.get("fail_on", ["P0", "P1"]))
        return result

    # ── zip 검사 ──
    def scan_zip(self, path: str) -> GuardResult:
        """zip 압축 패키지 재귀 검사."""
        return self.package_scanner.scan(path)


# ═══════════════════════════════════════════════════════════════════════════
# helper: 빠른 검사 함수
# ═══════════════════════════════════════════════════════════════════════════

def quick_scan_text(text: str, profile: str = "default") -> GuardResult:
    """1줄 빠른 텍스트 검사."""
    return Guard(profile=profile).scan_text(text)


def quick_scan_file(path: str, profile: str = "default") -> GuardResult:
    """1줄 빠른 파일 검사."""
    return Guard(profile=profile).scan_file(path)
