# 🦅 ARGUS Guard - 룰 정의 모음 (광범위 포괄)
#
# argus_guard:exempt-all
# (본 파일은 룰의 패턴 자체를 정의하므로, 자기 적용 시 false-positive 회피용 exempt)
#
# §35 자기 정정 누적 + 격언 #15~#120 v1 + Style Patch v1.2 + userPreferences 통합
# Commander Lignas 영구 명령 baseline (2026-05-19)

import re

# ═══════════════════════════════════════════════════════════════════════════
# 🚨 Style Patch v1.2 — Commander 영구 명령 (SSOT v1.10.142 + 178)
# ═══════════════════════════════════════════════════════════════════════════

# 🌟 금지어 3종 (Commander 확정 2026-05-19) — P0 즉시 실패
BANNED_TERMS = [
    "본질 baseline",
    "결정적 baseline",
    "정합 baseline",
]

# 카운트 제한 (응답당 최대 횟수)
STYLE_V12_LIMITS = {
    "baseline":  5,    # v1.1 등재
    "본격":      3,    # v1.2 등재
    "결정적":    3,    # v1.0 등재
}

# baseline 허용 4 case (SSOT v1.10.178)
BASELINE_ALLOWED_CASES = [
    "BT 비교 기준",         # "baseline vs candidate"
    "현재 운영 기준",       # "LIVE baseline"
    "기준 버전/파일",       # "v8.9.3 baseline", "Crown #67 baseline"
    "데이터/모델 기준선",   # "BT baseline"
]

# Style v1.2 대체어 매트릭스
REPLACEMENT_MAP = {
    "본질 baseline":   "본질 / 본질 기준 / 본질 차원",
    "결정적 baseline": "핵심 / 주요 / 중요한 기준",
    "정합 baseline":   "정합 / 정합 기준 / 일관 조건",
    "결정적":          "핵심 / 주요 / 중요 / 유의미 / 강한 / 주목할",
    "baseline":        "기준 / 현행 / 기준선 / 현 상태",
    "본격":            "정식 / 본 / 핵심 / 정밀",
}

# 한자 검출 (CJK Unified Ideographs)
CJK_PATTERN = re.compile(r"[\u3400-\u4DBF\u4E00-\u9FFF\uF900-\uFAFF]")

# 결정적 사용 3조건 (모두 충족 시만 허용)
DECISIVE_3_CONDITIONS = [
    "정량 증거 (BT 수치 / STRESS / FA / 코드 실행 결과)",
    "이진 판정 (GO/NO-GO / PASS/FAIL / 채택/거부)",
    "행동 결과 변경 (LIVE 금지 / 후보 격상 / SSOT 철회)",
]


# ═══════════════════════════════════════════════════════════════════════════
# 🚨 9-point checklist (격언 #116 + 9point_checklist_detail.md)
# ═══════════════════════════════════════════════════════════════════════════

# NO-GO 결정 발견 트리거 (이 단어 발견 시 9점검 의무 검증)
NO_GO_TRIGGER_TERMS = [
    "NO-GO", "No-Go", "NoGo", "FAIL", "거부", "기각", "폐기", "REJECTED",
]

# 9-point 각 항목 필수 키워드 (1+ 발견 시 점검 진행 인정)
NINE_POINT_REQUIRED_KEYWORDS = {
    1: ["분포", "평균", "중앙값", "std", "분위", "min", "max", "Δ>0"],
    2: ["sub-group", "하위 group", "보유 경과일", "regime별", "시기별", "group"],
    3: ["대안 자산", "현금", "SGOV", "TLT", "GLD", "Top5 이동", "자금 이동"],
    4: ["꼬리", "worst", "best", "손실 회피", "알파 손실", "outlier"],
    5: ["regime", "VIX", "WTI", "DXY", "Gate", "OAS", "T10YIE"],
    6: ["시기", "P1", "P2", "P3", "MID", "horizon", "fwd_h", "effective"],
    7: ["outlier", "이상값", "제외", "robust", "단일 case"],
    8: ["대상 확장", "다른 자산", "양수 자산", "신규 후보", "PAVE", "EWZ"],
    9: ["양방향", "Phase A noise", "negative confirmation", "단방향"],
}

NINE_POINT_DESCRIPTIONS = {
    1: "분포 점검 (평균/중앙값/std/분위/min-max/Δ>0%)",
    2: "하위 group 점검 (보유 경과일/regime별/시기별)",
    3: "대안 자산 점검 (자금 이동처 효과)",
    4: "꼬리 위험 점검 (outlier 영향 정량)",
    5: "Regime 분기 점검 (VIX/WTI/DXY)",
    6: "시간 분기 점검 (P1/P2/P3/MID + horizon)",
    7: "Outlier 진단 (제거 후 재평가)",
    8: "대상 확장 비교 (6+ 자산 동일 시뮬)",
    9: "양방향 격리 시뮬 (Phase A noise도 검증)",
}


# ═══════════════════════════════════════════════════════════════════════════
# 🚨 5-Tier Capital Level (격언 #118 v3 + #119 v2)
# ═══════════════════════════════════════════════════════════════════════════

CAPITAL_LEVELS = {
    0: "Discard (Signal/Capital 모두 거부)",
    1: "Signal/Regime/Monitor only (자본 직접 반영 아님)",
    2: "tie-breaker / ranking 보조 / confidence tag",
    3: "제한 cap (1~3% sleeve)",
    4: "정식 capital (RULE 29 v2 통과)",
    5: "Crown 격상 (LIVE 채택)",
}

# era-conditional 분기 (격언 #119 v2 갱신)
ERA_LABELS = ["P1", "P2", "P3", "MID", "FULL"]

# §35 #13: v1 단순 매핑 vs v2 정밀 측정 분기 검출
ERA_CONDITIONAL_TRIGGER_PATTERNS = [
    re.compile(r"FULL\s*평균"),
    re.compile(r"FULL\s*기준"),
    re.compile(r"전체\s*평균"),
]


# ═══════════════════════════════════════════════════════════════════════════
# 🚨 Signal/Capital 5 Layer 분리 (격언 #112 v2 #9 v2)
# ═══════════════════════════════════════════════════════════════════════════

SIGNAL_CAPITAL_5_LAYERS = {
    "Signal Layer":       ["GO", "보류", "폐기"],
    "Regime Tag":         ["GO", "보류", "해당 없음"],
    "Monitoring":         ["GO", "보류", "해당 없음"],
    "Research Registry":  ["GO", "보류", "폐기"],
    "Capital Allocation": ["GO", "제한 반영", "보류", "금지"],
}

# 위험 패턴 (Signal/Capital 혼동) — §35 #12 위반 차단
SIGNAL_CAPITAL_BAD_PATTERNS = [
    (re.compile(r"portfolio\s*alpha\s*[~=≈]?\s*0.{0,30}signal\s*폐기", re.IGNORECASE | re.DOTALL),
     "포트폴리오 alpha 0만으로 signal 폐기 = §35 #12 위반"),
    (re.compile(r"alpha\s*[~=≈]?\s*0\s*.{0,20}NO[\s-]?GO", re.IGNORECASE | re.DOTALL),
     "alpha 0 → NO-GO 단일 차원 판정 금지 (§35 #12)"),
    (re.compile(r"Top5\s*0\s*%?.{0,20}신호\s*실패", re.IGNORECASE | re.DOTALL),
     "Top5 0% = 신호 실패 = 격언 #120 v1 Top5 참여 편향 미진단"),
    (re.compile(r"진입\s*률\s*0.{0,20}NO[\s-]?GO", re.IGNORECASE | re.DOTALL),
     "진입률 0 → NO-GO = 격언 #120 v1 Uninvestable Alpha 미인지"),
]


# ═══════════════════════════════════════════════════════════════════════════
# 🚨 Top5 참여 편향 8 항목 (격언 #120 v1)
# ═══════════════════════════════════════════════════════════════════════════

TOP5_BIAS_8_ITEMS = [
    "signal ON 일수",
    "실제 Top5 진입률",
    "평균 rank",
    "shadow forward return",
    "hit rate",
    "payoff",
    "participation-adjusted score",
    "실제 portfolio alpha",
]

# Top5 검증 트리거 키워드
TOP5_BIAS_TRIGGER_TERMS = [
    "Top5", "Top 5", "참여", "진입률", "rank", "Uninvestable", "shadow",
]


# ═══════════════════════════════════════════════════════════════════════════
# 🚨 Crown 닫힌 표현 (격언 #74 + #98)
# ═══════════════════════════════════════════════════════════════════════════

CROWN_CLOSED_PATTERNS = [
    (re.compile(r"Crown\s*#?\d*\s*완전\s*폐기"),
     "Crown 완전 폐기 = 격언 #74 위반. '보류 / LIVE 미진입 / baseline 보존' 권장"),
    (re.compile(r"후보\s*영구\s*폐기"),
     "영구 폐기 = 격언 #74 위반. 'CANDIDATE 상태 유지 + LIVE 미진입' 권장"),
    (re.compile(r"향후\s*검토\s*불가|재검토\s*불가"),
     "향후 검토 불가 = 격언 #98 위반. '다음 cycle 재검토 가능' 권장"),
    (re.compile(r"signal\s*완전\s*폐기"),
     "signal 완전 폐기 = 격언 #117 + #118 위반. 'Tier 1 Signal Layer 유지' 권장"),
    (re.compile(r"전\s*면\s*폐기"),
     "전면 폐기 = 격언 #74 위반. '제한 반영 또는 Signal Layer 보존' 권장"),
]

CROWN_RECOMMENDED_PATTERNS = [
    "Crown #N LIVE baseline 영구 유지",
    "후보 거부 (CANDIDATE 상태 유지, LIVE 미진입)",
    "Signal Layer 보존 (Capital Level 1)",
    "다음 cycle 재검토 baseline 보존",
]


# ═══════════════════════════════════════════════════════════════════════════
# 🚨 평균값 단독 결론 (§35 #11)
# ═══════════════════════════════════════════════════════════════════════════

AVERAGE_ONLY_BAD_PATTERNS = [
    (re.compile(r"평균\s*[~=≈]?\s*[+\-]?\d+\.?\d*\s*p?\s*.{0,30}NO[\s-]?GO", re.IGNORECASE | re.DOTALL),
     "평균값 단독 → NO-GO = §35 #11 위반. 중앙값+std+분위+Δ>0% 동시 보고 의무"),
    (re.compile(r"mean\s*[~=≈]?\s*[+\-]?\d+\.?\d*.{0,30}reject", re.IGNORECASE | re.DOTALL),
     "mean only → reject = §35 #11 위반"),
    (re.compile(r"평균만\s*보고\s*결정"),
     "평균만 보고 결정 = §35 #11 위반"),
]


# ═══════════════════════════════════════════════════════════════════════════
# 🚨 Phase A 단독 평가 (격언 #25 + #52 + #117)
# ═══════════════════════════════════════════════════════════════════════════

PHASE_A_ONLY_BAD_PATTERNS = [
    (re.compile(r"Phase\s*A\s*t\s*[><=≥≤]\s*[+\-]?\d+\.?\d*.{0,40}채택", re.IGNORECASE | re.DOTALL),
     "Phase A t-stat → 채택 = 격언 #25 + #52 위반. §B.9 slot 사전 검증 의무"),
    (re.compile(r"Phase\s*A\s*강.{0,30}Crown\s*격상", re.IGNORECASE | re.DOTALL),
     "Phase A 강도 → Crown 격상 = 격언 #117 위반. 양방향 추론 금지"),
    (re.compile(r"Phase\s*A\s*noise.{0,30}전면\s*NO[\s-]?GO", re.IGNORECASE | re.DOTALL),
     "Phase A noise → 전면 NO-GO = 격언 #117 위반. Phase B-6 격리 의무"),
]


# ═══════════════════════════════════════════════════════════════════════════
# 🚨 정량 근거 없는 거부 (기만 차단 5조 #3)
# ═══════════════════════════════════════════════════════════════════════════

QUANTITATIVE_EVIDENCE_REQUIRED_TRIGGERS = [
    "NO-GO", "No-Go", "거부", "기각", "FAIL", "폐기", "REJECTED",
]

# 정량 근거 패턴 (있어야 정합)
QUANTITATIVE_EVIDENCE_PATTERNS = [
    re.compile(r"[+\-]?\d+\.?\d*\s*p\b"),               # +N.NNp
    re.compile(r"[+\-]?\d+\.?\d*\s*%"),                 # +N.NN%
    re.compile(r"Sharpe\s*[+\-]?\d+\.?\d*", re.I),      # Sharpe N
    re.compile(r"CAGR\s*[+\-]?\d+\.?\d*", re.I),        # CAGR N
    re.compile(r"MDD\s*[+\-]?\d+\.?\d*", re.I),         # MDD N
    re.compile(r"t\s*[=:]\s*[+\-]?\d+\.?\d*"),          # t=N
    re.compile(r"STRESS\s*\d+\s*/\s*\d+"),              # STRESS 14/14
    re.compile(r"RULE\s*29", re.I),                     # RULE 29 v2
    re.compile(r"n\s*[=:]\s*\d+"),                      # n=N
    re.compile(r"p\s*[=:≤<]\s*0?\.\d+"),                # p=0.NN
]


# ═══════════════════════════════════════════════════════════════════════════
# 🚨 시간 지연 / "다음 세션" 미루기 (기만 차단 5조 #4)
# ═══════════════════════════════════════════════════════════════════════════

TIME_DEFERRAL_BAD_PATTERNS = [
    (re.compile(r"다음\s*(세션|cycle|사이클)\s*에\s*결정", re.IGNORECASE),
     "다음 세션 결정 미루기 = 기만 차단 5조 #4 위반. 본 cycle 결정 의무"),
    (re.compile(r"추후\s*에?\s*검토"),
     "추후 검토 = 시간 지연 가능성. 본 cycle 결정 의무 검증"),
    (re.compile(r"나중에\s*결정"),
     "나중에 결정 = 기만 차단 5조 #4 가능 위반"),
    (re.compile(r"일반\s*화\s*거부", re.IGNORECASE),
     "일반화 거부 = 기만 차단 5조 #4 위반"),
]


# ═══════════════════════════════════════════════════════════════════════════
# 🚨 Blanket signal (격언 #48 + #75 v4)
# ═══════════════════════════════════════════════════════════════════════════

BLANKET_SIGNAL_BAD_PATTERNS = [
    (re.compile(r"전\s*종목\s*즉시\s*청산"),
     "전종목 블랭킷 청산 = 격언 #48 + #75 v4 위반. 종목별 검증 의무"),
    (re.compile(r"WTI\s*[><=]\s*\$?9?0\s*즉\s*차단"),
     "WTI>90 블랭킷 차단 = 격언 #75 v4 위반. _wk_xle 분리 의무"),
    (re.compile(r"전종목\s*Gate\s*차단"),
     "전종목 Gate 차단 = 격언 #48 위반. ticker별 hysteresis 분리 의무"),
    (re.compile(r"일률\s*적용", re.IGNORECASE),
     "일률 적용 = 격언 #48 위반 가능. ticker별 분리 검증 의무"),
]


# ═══════════════════════════════════════════════════════════════════════════
# 🚨 Internal BT only (격언 #97 v2)
# ═══════════════════════════════════════════════════════════════════════════

INTERNAL_BT_ONLY_BAD_PATTERNS = [
    (re.compile(r"내부\s*BT\s*만.{0,20}Crown\s*채택", re.IGNORECASE | re.DOTALL),
     "내부 BT 단독 → Crown 채택 = 격언 #97 v2 위반. 외부 FA 의무"),
    (re.compile(r"BT\s*만\s*보고\s*LIVE", re.IGNORECASE),
     "BT 단독 → LIVE = 격언 #97 v2 위반"),
    (re.compile(r"외부\s*FA\s*생략", re.IGNORECASE),
     "외부 FA 생략 = 격언 #97 v2 위반. Crown #65 NO-GO 재현 위험"),
]


# ═══════════════════════════════════════════════════════════════════════════
# 🚨 Entry/Exit threshold 분리 (격언 #79)
# ═══════════════════════════════════════════════════════════════════════════

ENTRY_EXIT_CONFUSION_PATTERNS = [
    (re.compile(r"entry\s*threshold\s*=\s*exit\s*threshold", re.IGNORECASE),
     "entry = exit threshold = 격언 #79 위반. 정보 구조 분리 의무"),
    (re.compile(r"진입\s*임계.{0,20}청산\s*임계.{0,20}동일", re.DOTALL),
     "진입/청산 임계 동일 = 격언 #79 위반"),
]


# ═══════════════════════════════════════════════════════════════════════════
# 🚨 Crown #65 영구 회피 — ENTRY_THRESHOLD vs hard-coded 분리 (§35.NEW_11)
# ═══════════════════════════════════════════════════════════════════════════

ENTRY_THRESHOLD_DICT_PATTERN = re.compile(r"ENTRY_THRESHOLD\s*[=\[\{]")
HARDCODED_RETURN_PATTERN = re.compile(r"return\s+s\s*>\s*[\d.]+(?!\w)")  # return s > N (not ENTRY_THRESHOLD)


# ═══════════════════════════════════════════════════════════════════════════
# 🚨 미봉책 표현 (userPreferences + 격언 #106)
# ═══════════════════════════════════════════════════════════════════════════

PATCHWORK_BAD_PATTERNS = [
    (re.compile(r"일시\s*적\s*우회", re.IGNORECASE),
     "일시 우회 = userPreferences '근본 대책만' 위반"),
    (re.compile(r"임시\s*적?\s*패치", re.IGNORECASE),
     "임시 패치 = 격언 #106 (근본 처방) 위반"),
    (re.compile(r"미봉책", re.IGNORECASE),
     "미봉책 = userPreferences '근본 대책만' 위반"),
    (re.compile(r"단순히\s*hard[\s-]?code", re.IGNORECASE),
     "단순 hard-code = 격언 #106 위반"),
    (re.compile(r"monkey[\s-]?patch", re.IGNORECASE),
     "monkey-patch = 격언 #56 위반 (§40 v3 BT 의무)"),
]


# ═══════════════════════════════════════════════════════════════════════════
# 🚨 LIVE 값 표기 (userPreferences)
# ═══════════════════════════════════════════════════════════════════════════

# LIVE 값 후보 (수치 + 지표) — 이 패턴 발견 시 🌟 ** ** 🌟 wrapping 의무
LIVE_VALUE_CANDIDATE_PATTERN = re.compile(
    r"(Sharpe|MDD|CAGR|t-?stat|alpha|ΔCAGR|ΔSharpe|ΔMDD|Crown\s*#\d+|"
    r"\d+\.\d+\s*p\b|\$\d+\.\d+|[+\-]?\d+\.\d+\s*%)",
    re.IGNORECASE,
)

LIVE_VALUE_WRAPPED_PATTERN = re.compile(
    r"🌟\s*\*\*[^*]+\*\*\s*🌟"
)


# ═══════════════════════════════════════════════════════════════════════════
# 🚨 약어 풀이 (userPreferences)
# ═══════════════════════════════════════════════════════════════════════════

ABBREVIATION_DEFINITIONS = {
    "BT":       "Backtest",
    "FA":       "Forensic Audit",
    "REG":      "Regret Log",
    "SSOT":     "Single Source of Truth",
    "GHA":      "GitHub Actions",
    "MDD":      "Maximum Drawdown",
    "CAGR":     "Compound Annual Growth Rate",
    "EnSn":     "Entry Signal",
    "EASn":     "Entry Avoidance Signal",
    "ExSn":     "Exit Signal",
    "MoSn":     "Momentum Signal",
    "STRESS":   "Stress Test (14 scenarios)",
    "PRIMA":    "PRIMA engine (ARGUS core)",
    "ARGUS":    "Argus ETF Rotation System",
    "LIVE":     "Live operation status",
    "PAT":      "Personal Access Token",
    "ETF":      "Exchange Traded Fund",
    "PMI":      "Purchasing Managers Index",
    "VIX":      "Volatility Index (CBOE)",
    "WTI":      "West Texas Intermediate (oil)",
    "DXY":      "US Dollar Index",
    "OAS":      "Option-Adjusted Spread",
}


# ═══════════════════════════════════════════════════════════════════════════
# 🚨 결론 우선 / 시간 예상 / 번호 목록 / HTML (userPreferences)
# ═══════════════════════════════════════════════════════════════════════════

CONCLUSION_FIRST_REQUIRED_MARKERS = [
    "🎯 결론", "🎯 결산", "결론 우선", "🎯 본질", "Status:",
    "🎯 결정",
]

TIME_ESTIMATE_PATTERN = re.compile(
    r"(소요|예상\s*소요|약\s*\d+\s*분|~\s*\d+\s*분|⏱️)",
    re.IGNORECASE,
)

# "1. " 형식 텍스트 번호 목록 (userPreferences 금지)
# 단, 표 안 (|1.|) / 코드 (1. import) 영역 제외
NUMBERED_LIST_PATTERN = re.compile(
    r"^\s*\d+\.\s+(?![a-zA-Z_])",
    re.MULTILINE,
)

HTML_TAG_PATTERN = re.compile(
    r"<(br|table|tr|td|th|div|span|h[1-6]|p|ul|ol|li|a|img|iframe)\b",
    re.IGNORECASE,
)


# ═══════════════════════════════════════════════════════════════════════════
# 🚨 v1.0.1 추가 룰 — 메모리/격언 누적 §35 누락 사례 통합
# ═══════════════════════════════════════════════════════════════════════════

# ─────────────────────────────────────────────────────────────
# P1_DATA_FABRICATION (불가침 SSOT 5조 ③ — 데이터 위조 절대 금지)
# 추정/추측/임의값 사용 시 N/A 또는 정량 근거 첨부 의무
# ─────────────────────────────────────────────────────────────

DATA_FABRICATION_BAD_PATTERNS = [
    (re.compile(r"대\s*략\s*[+\-]?\d+\.?\d*"), 
     "'대략 N' 추정값 = 불가침 SSOT ③ 위반. 정량 근거 또는 N/A 표시 의무"),
    (re.compile(r"아\s*마\s*[+\-]?\d+\.?\d*"),
     "'아마 N' 추정값 = 불가침 SSOT ③ 위반"),
    (re.compile(r"임의\s*로\s*[+\-]?\d+\.?\d*"),
     "임의값 = 불가친 SSOT ③ 위반"),
    (re.compile(r"추정\s*값\s*[+\-]?\d+\.?\d*"),
     "'추정값 N'은 source 명시 + (추정) 표기 의무"),
]

# 합법 표현 패턴 (있으면 면제)
DATA_FABRICATION_ALLOWED_PATTERNS = [
    re.compile(r"\(추정\)", re.IGNORECASE),
    re.compile(r"\(estimate\)", re.IGNORECASE),
    re.compile(r"N/A"),
    re.compile(r"source\s*[:=]", re.IGNORECASE),
]


# ─────────────────────────────────────────────────────────────
# P1_BUNDLE_SPLIT (운영 SSOT ① — 묶음 작업 분리 금지)
# 결정문이 여러 응답으로 쪼개진 경우 검출 (응답 단독으로는 어려움)
# 텍스트 내 부분 결정 / TBD / pending 누적 검출
# ─────────────────────────────────────────────────────────────

BUNDLE_SPLIT_BAD_PATTERNS = [
    (re.compile(r"부분\s*결정\s*(만|뿐)", re.IGNORECASE),
     "부분 결정 = 묶음 작업 분리 = 운영 SSOT ① 위반"),
    (re.compile(r"세부는?\s*다음\s*응답"),
     "세부 다음 응답 분리 = 묶음 작업 위반"),
    (re.compile(r"분할\s*결정문"),
     "분할 결정문 = 묶음 작업 위반"),
]


# ─────────────────────────────────────────────────────────────
# P1_AXIOM_OVERUSE (운영 SSOT ③ — 응답당 격언 인용 ≤5건)
# ─────────────────────────────────────────────────────────────

AXIOM_REFERENCE_PATTERN = re.compile(r"격언\s*#\d+")
AXIOM_OVERUSE_LIMIT = 5  # 운영 SSOT ③


# ─────────────────────────────────────────────────────────────
# P1_VERSION_NO_DIFF (§42 — 버전 변경 시 V-Diff 의무)
# 버전 변경 표현 + diff 부재
# ─────────────────────────────────────────────────────────────

VERSION_CHANGE_TRIGGERS = [
    re.compile(r"v\d+\.\d+\.\d+\s*→\s*v\d+\.\d+\.\d+"),
    re.compile(r"version\s*bump", re.IGNORECASE),
    re.compile(r"버전\s*격상"),
    re.compile(r"버전\s*변경"),
    re.compile(r"패치\s*적용"),
]

V_DIFF_PATTERNS = [
    re.compile(r"(➕|➖|✏️)"),
    re.compile(r"V-Diff", re.IGNORECASE),
    re.compile(r"신구\s*diff"),
    re.compile(r"diff\s*출력"),
    re.compile(r"(added|removed|modified)", re.IGNORECASE),
]


# ─────────────────────────────────────────────────────────────
# P1_EXSN_PREEVAL_MISSING (격언 #87 — ExSn 사전 평가 의무)
# 진입/채택 결정 + 보유 中 ExSn 측정 누락
# ─────────────────────────────────────────────────────────────

ENTRY_DECISION_TRIGGERS = [
    re.compile(r"진입\s*(결정|채택|승인)"),
    re.compile(r"채택\s*결정"),
    re.compile(r"Crown\s*격상"),
    re.compile(r"LIVE\s*진입"),
]

EXSN_EVALUATION_PATTERNS = [
    re.compile(r"ExSn\s*사전\s*평가", re.IGNORECASE),
    re.compile(r"exit\s*signal\s*pre", re.IGNORECASE),
    re.compile(r"ExSn\s*우선순위", re.IGNORECASE),
    re.compile(r"청산\s*시그널\s*분석"),
    re.compile(r"exit\s*평가"),
]


# ─────────────────────────────────────────────────────────────
# P1_SINGLE_ASSET_BOOST (격언 #112 v2 #9 v2 — Single-Asset Boost 위험)
# 단일 자산 100% / TLT 100% / boost 효과 단독 채택
# ─────────────────────────────────────────────────────────────

SINGLE_ASSET_BOOST_TRIGGERS = [
    re.compile(r"단일\s*자산\s*boost", re.IGNORECASE),
    re.compile(r"단일\s*종목\s*100\s*%"),
    re.compile(r"\b[A-Z]{2,5}\s*100\s*%\s*채택"),
    re.compile(r"single[\s-]?asset\s*boost", re.IGNORECASE),
]

SINGLE_ASSET_BOOST_REQUIRED_VERIFICATIONS = [
    "diversification",
    "분산",
    "alternative",
    "대안",
    "보조 자산",
    "concentration risk",
    "집중 위험",
]


# ─────────────────────────────────────────────────────────────
# P1_DEAD_SOURCE (격언 #67 v3 + #96 v2 ② — dead source 사용 금지)
# DBnomics PMI 등 dead source 시도 검출
# ─────────────────────────────────────────────────────────────

DEAD_SOURCE_BAD_PATTERNS = [
    (re.compile(r"DBnomics\s*ISM/pmi/pm", re.IGNORECASE),
     "DBnomics ISM/pmi/pm = dead source (2025-09 이후 오염). 격언 #67 v3 + #96 v2 ② 위반"),
    (re.compile(r"NAPM\b.*활성", re.IGNORECASE),
     "NAPM = 2024-01-01 discontinued. 격언 #67 v3 위반"),
    (re.compile(r"DBnomics.*신호\s*활성"),
     "DBnomics 신호 활성 = source sanity 미검증. 격언 #96 v2 ② 위반"),
]


# ─────────────────────────────────────────────────────────────
# P2_COMMANDER_AUTHORITY_MISSING (격언 #15 — Commander 절대 결정권)
# Claude가 "채택 결정" 표현 + Commander 권한 분리 누락
# ─────────────────────────────────────────────────────────────

CLAUDE_DECISION_TRIGGERS = [
    re.compile(r"채택\s*(결정|확정)"),
    re.compile(r"승인\s*확정"),
    re.compile(r"LIVE\s*확정"),
    re.compile(r"Crown\s*격상\s*결정"),
]

COMMANDER_AUTHORITY_PATTERNS = [
    re.compile(r"Commander\s*(승인|결정|선택)"),
    re.compile(r"권고", re.IGNORECASE),
    re.compile(r"recommendation", re.IGNORECASE),
    re.compile(r"PRIMA.*권고\s*only"),
    re.compile(r"ARGUS.*권고"),
    re.compile(r"최종.*Commander"),
]

RULES_REGISTRY = {
    # ── P0 (즉시 실패) ──
    "P0_BANNED_TERMS": {
        "severity": "P0",
        "domain":   "style_v12",
        "desc":     "Style v1.2 금지어 3종 (본질/결정적/정합 baseline)",
        "axiom":    "Commander 영구 명령 + SSOT v1.10.142+178",
    },
    "P0_CJK_CHARS": {
        "severity": "P0",
        "domain":   "language",
        "desc":     "한자 검출 (userPreferences 한국어 원칙)",
        "axiom":    "userPreferences",
    },

    # ── P1 (보고서 승인 금지) ──
    "P1_BASELINE_OVERUSE": {
        "severity": "P1",
        "domain":   "style_v12",
        "desc":     "'baseline' >5회/응답",
        "axiom":    "SSOT v1.10.178 Style Patch v1.2",
    },
    "P1_BONGYUK_OVERUSE": {
        "severity": "P1",
        "domain":   "style_v12",
        "desc":     "'본격' >3회/응답",
        "axiom":    "SSOT v1.10.178 Style Patch v1.2",
    },
    "P1_DECISIVE_OVERUSE": {
        "severity": "P1",
        "domain":   "style_v12",
        "desc":     "'결정적' >3회/응답",
        "axiom":    "SSOT v1.10.142 Style Patch v1.0",
    },
    "P1_CROWN_CLOSED": {
        "severity": "P1",
        "domain":   "logic",
        "desc":     "Crown 닫힌 표현 ('완전 폐기 / 향후 검토 불가')",
        "axiom":    "격언 #74 + #98",
    },
    "P1_SIGNAL_CAPITAL_BAD": {
        "severity": "P1",
        "domain":   "logic",
        "desc":     "Signal/Capital 혼동 (alpha 0 → NO-GO 단일 차원)",
        "axiom":    "§35 #12 + 격언 #118 v3 + #120 v1",
    },
    "P1_NO_GO_9POINT_MISSING": {
        "severity": "P1",
        "domain":   "logic",
        "desc":     "NO-GO 결정 前 9-point checklist 누락",
        "axiom":    "격언 #116 + 9point_checklist_detail.md",
    },
    "P1_PARTICIPATION_BIAS": {
        "severity": "P1",
        "domain":   "logic",
        "desc":     "Top5 참여 편향 8 항목 점검 누락",
        "axiom":    "격언 #120 v1 (CAND-S121_β)",
    },
    "P1_AVERAGE_ONLY": {
        "severity": "P1",
        "domain":   "logic",
        "desc":     "평균값 단독 결론 (중앙값+std+분위 누락)",
        "axiom":    "§35 #11",
    },
    "P1_PHASE_A_ONLY": {
        "severity": "P1",
        "domain":   "logic",
        "desc":     "Phase A 단독 평가 → 채택/거부 결정",
        "axiom":    "격언 #25 + #52 + #117",
    },
    "P1_QUANTITATIVE_MISSING": {
        "severity": "P1",
        "domain":   "evidence",
        "desc":     "정량 근거 없는 거부 (NO-GO/거부/기각)",
        "axiom":    "기만 차단 5조 #3 + 격언 #6",
    },
    "P1_TIME_DEFERRAL": {
        "severity": "P1",
        "domain":   "evidence",
        "desc":     "시간 지연 / '다음 세션' 미루기",
        "axiom":    "기만 차단 5조 #4",
    },
    "P1_BLANKET_SIGNAL": {
        "severity": "P1",
        "domain":   "engine",
        "desc":     "블랭킷 시그널 ('전종목 즉시 청산')",
        "axiom":    "격언 #48 + #75 v4",
    },
    "P1_INTERNAL_BT_ONLY": {
        "severity": "P1",
        "domain":   "engine",
        "desc":     "내부 BT 단독 → Crown 채택 (외부 FA 생략)",
        "axiom":    "격언 #97 v2 (Crown #65 NO-GO 재현 위험)",
    },
    "P1_ENTRY_THRESHOLD_SPLIT": {
        "severity": "P1",
        "domain":   "engine",
        "desc":     "ENTRY_THRESHOLD dict vs hard-coded 'return s > N' 분리",
        "axiom":    "§35.NEW_11 (Crown #65 NO-GO 원인)",
    },
    "P1_ENTRY_EXIT_CONFUSION": {
        "severity": "P1",
        "domain":   "engine",
        "desc":     "entry threshold = exit threshold (정보 구조 미분리)",
        "axiom":    "격언 #79",
    },
    "P1_PATCHWORK": {
        "severity": "P1",
        "domain":   "logic",
        "desc":     "미봉책 표현 (일시/임시 우회, monkey-patch)",
        "axiom":    "userPreferences + 격언 #56 + #106",
    },
    "P1_ERA_CONDITIONAL_MISSING": {
        "severity": "P1",
        "domain":   "logic",
        "desc":     "era 분기 측정 누락 (FULL 평균만)",
        "axiom":    "§35 #13 + 격언 #119 v2",
    },

    # ── P2 (수정 권고) ──
    "P2_LIVE_VALUE_UNWRAPPED": {
        "severity": "P2",
        "domain":   "preferences",
        "desc":     "LIVE 값 🌟 ** ** 🌟 wrapping 누락",
        "axiom":    "userPreferences",
    },
    "P2_ABBREVIATION_UNDEFINED": {
        "severity": "P2",
        "domain":   "preferences",
        "desc":     "약어 첫 등장 시 풀이 누락",
        "axiom":    "userPreferences",
    },
    "P2_TIME_ESTIMATE_MISSING": {
        "severity": "P2",
        "domain":   "preferences",
        "desc":     "예상 소요 표시 누락 ('⏱️ 약 N분')",
        "axiom":    "userPreferences",
    },
    "P2_CONCLUSION_FIRST_MISSING": {
        "severity": "P2",
        "domain":   "preferences",
        "desc":     "결론 우선 구조 마커 누락 ('🎯 결론')",
        "axiom":    "userPreferences",
    },

    # ── P3 (경고) ──
    "P3_NUMBERED_LIST": {
        "severity": "P3",
        "domain":   "preferences",
        "desc":     "텍스트 번호 목록 사용 (1. 2. 3.)",
        "axiom":    "userPreferences",
    },
    "P3_HTML_TAG": {
        "severity": "P3",
        "domain":   "preferences",
        "desc":     "HTML 태그 사용 (<br>, <table> 등)",
        "axiom":    "userPreferences",
    },

    # ═══════════════════════════════════════════════════════════════════════
    # v1.0.1 추가 룰 (메모리/격언 누적 §35 누락 사례)
    # ═══════════════════════════════════════════════════════════════════════
    "P1_DATA_FABRICATION": {
        "severity": "P1",
        "domain":   "evidence",
        "desc":     "추정/추측/임의값 미명시 (N/A 또는 정량 근거 의무)",
        "axiom":    "불가침 SSOT 5조 ③ (메모리 #15)",
    },
    "P1_BUNDLE_SPLIT": {
        "severity": "P1",
        "domain":   "logic",
        "desc":     "결정문 분리 출력 (묶음 작업 의무 위반)",
        "axiom":    "운영 SSOT ① + 격언 #67 v3",
    },
    "P1_AXIOM_OVERUSE": {
        "severity": "P1",
        "domain":   "style_v12",
        "desc":     "응답당 격언 인용 >5건 초과 (운영 SSOT ③)",
        "axiom":    "운영 SSOT ③ + 격언 #110",
    },
    "P1_VERSION_NO_DIFF": {
        "severity": "P1",
        "domain":   "engine",
        "desc":     "버전 변경 시 V-Diff (➕➖✏️) 누락",
        "axiom":    "§42 + 격언 #16 (메모리 #21)",
    },
    "P1_EXSN_PREEVAL_MISSING": {
        "severity": "P1",
        "domain":   "logic",
        "desc":     "진입/채택 결정 + ExSn 사전 평가 누락",
        "axiom":    "격언 #87 + #94",
    },
    "P1_SINGLE_ASSET_BOOST": {
        "severity": "P1",
        "domain":   "engine",
        "desc":     "단일 자산 boost 위험 미검증 (분산 효과 확인 의무)",
        "axiom":    "격언 #112 v2 #9 v2",
    },
    "P1_DEAD_SOURCE": {
        "severity": "P1",
        "domain":   "engine",
        "desc":     "dead source (DBnomics PMI 등) 사용 시도",
        "axiom":    "격언 #67 v3 + #96 v2 ②",
    },
    "P2_COMMANDER_AUTHORITY_MISSING": {
        "severity": "P2",
        "domain":   "preferences",
        "desc":     "Claude 채택 결정 표현 + Commander 권한 분리 누락",
        "axiom":    "격언 #15 + 불가침 SSOT 5조 ⑤",
    },
}
