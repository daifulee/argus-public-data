# 🦅 ARGUS Guard - 프로필별 룰 매트릭스
# argus_guard:exempt-all
#
# default = 모든 룰 활성
# response = 대화 응답 (Style v1.2 + userPreferences 위주)
# reg      = REG (Regret Log) 결정문 (Style v1.2 + Crown 표현 + 9point + Top5 + 5-Tier)
# engine   = PRIMA 엔진 .py 파일 (ENTRY_THRESHOLD + blanket + entry/exit)
# briefing = prima_briefing.py (banned phrases + Crown 매핑)
# ssot     = SSOT 결정문 (baseline 4-case 허용 완화)
# handoff  = 세션 handoff 문서

# 모든 룰 (RULES_REGISTRY 와 동일)
ALL_RULES = [
    # P0
    "P0_BANNED_TERMS",
    "P0_CJK_CHARS",
    # P1
    "P1_BASELINE_OVERUSE",
    "P1_BONGYUK_OVERUSE",
    "P1_DECISIVE_OVERUSE",
    "P1_CROWN_CLOSED",
    "P1_SIGNAL_CAPITAL_BAD",
    "P1_NO_GO_9POINT_MISSING",
    "P1_PARTICIPATION_BIAS",
    "P1_AVERAGE_ONLY",
    "P1_PHASE_A_ONLY",
    "P1_QUANTITATIVE_MISSING",
    "P1_TIME_DEFERRAL",
    "P1_BLANKET_SIGNAL",
    "P1_INTERNAL_BT_ONLY",
    "P1_ENTRY_THRESHOLD_SPLIT",
    "P1_ENTRY_EXIT_CONFUSION",
    "P1_PATCHWORK",
    "P1_ERA_CONDITIONAL_MISSING",
    # v1.0.1 P1 추가
    "P1_DATA_FABRICATION",
    "P1_BUNDLE_SPLIT",
    "P1_AXIOM_OVERUSE",
    "P1_VERSION_NO_DIFF",
    "P1_EXSN_PREEVAL_MISSING",
    "P1_SINGLE_ASSET_BOOST",
    "P1_DEAD_SOURCE",
    # P2
    "P2_LIVE_VALUE_UNWRAPPED",
    "P2_ABBREVIATION_UNDEFINED",
    "P2_TIME_ESTIMATE_MISSING",
    "P2_CONCLUSION_FIRST_MISSING",
    # v1.0.1 P2 추가
    "P2_COMMANDER_AUTHORITY_MISSING",
    # P3
    "P3_NUMBERED_LIST",
    "P3_HTML_TAG",
]


PROFILES = {
    # ═════════════════════════════════════════════════════════════
    # default : 전 영역 활성 (가장 엄격)
    # ═════════════════════════════════════════════════════════════
    "default": {
        "name":               "default",
        "description":        "전 영역 활성 — 모든 룰 적용 (가장 엄격)",
        "enabled_rules":      ALL_RULES,
        "fail_on":            ["P0", "P1"],
        "baseline_limit":     5,
        "bongyuk_limit":      3,
        "decisive_limit":     3,
        "doc_baseline_relax": False,
    },

    # ═════════════════════════════════════════════════════════════
    # response : 대화 응답 검사 (Style + preferences)
    # ═════════════════════════════════════════════════════════════
    "response": {
        "name":          "response",
        "description":   "대화 응답 검사 — Style v1.2 + userPreferences + v1.0.1 신규",
        "enabled_rules": [
            "P0_BANNED_TERMS",
            "P0_CJK_CHARS",
            "P1_BASELINE_OVERUSE",
            "P1_BONGYUK_OVERUSE",
            "P1_DECISIVE_OVERUSE",
            "P1_TIME_DEFERRAL",
            "P1_PATCHWORK",
            # v1.0.1 신규
            "P1_DATA_FABRICATION",
            "P1_AXIOM_OVERUSE",
            "P2_LIVE_VALUE_UNWRAPPED",
            "P2_ABBREVIATION_UNDEFINED",
            "P2_TIME_ESTIMATE_MISSING",
            "P2_CONCLUSION_FIRST_MISSING",
            "P2_COMMANDER_AUTHORITY_MISSING",
            "P3_NUMBERED_LIST",
            "P3_HTML_TAG",
        ],
        "fail_on":            ["P0", "P1"],
        "baseline_limit":     5,
        "bongyuk_limit":      3,
        "decisive_limit":     3,
        "doc_baseline_relax": False,
    },

    # ═════════════════════════════════════════════════════════════
    # reg : REG (Regret Log) 결정문
    # ═════════════════════════════════════════════════════════════
    "reg": {
        "name":          "reg",
        "description":   "REG 결정문 — Style + Crown + 9point + Top5 + 5-Tier + Signal/Capital + v1.0.1 신규",
        "enabled_rules": [
            "P0_BANNED_TERMS",
            "P0_CJK_CHARS",
            "P1_BASELINE_OVERUSE",
            "P1_BONGYUK_OVERUSE",
            "P1_DECISIVE_OVERUSE",
            "P1_CROWN_CLOSED",
            "P1_SIGNAL_CAPITAL_BAD",
            "P1_NO_GO_9POINT_MISSING",
            "P1_PARTICIPATION_BIAS",
            "P1_AVERAGE_ONLY",
            "P1_PHASE_A_ONLY",
            "P1_QUANTITATIVE_MISSING",
            "P1_TIME_DEFERRAL",
            "P1_INTERNAL_BT_ONLY",
            "P1_PATCHWORK",
            "P1_ERA_CONDITIONAL_MISSING",
            # v1.0.1 신규
            "P1_DATA_FABRICATION",
            "P1_BUNDLE_SPLIT",
            "P1_AXIOM_OVERUSE",
            "P1_EXSN_PREEVAL_MISSING",
            "P1_SINGLE_ASSET_BOOST",
            "P2_LIVE_VALUE_UNWRAPPED",
            "P2_COMMANDER_AUTHORITY_MISSING",
        ],
        "fail_on":            ["P0", "P1"],
        "baseline_limit":     8,
        "bongyuk_limit":      5,
        "decisive_limit":     5,
        "doc_baseline_relax": True,
    },

    # ═════════════════════════════════════════════════════════════
    # engine : PRIMA 엔진 .py 파일
    # ═════════════════════════════════════════════════════════════
    "engine": {
        "name":          "engine",
        "description":   "PRIMA 엔진 .py — ENTRY_THRESHOLD + blanket + entry/exit + v1.0.1 신규",
        "enabled_rules": [
            "P0_BANNED_TERMS",
            "P0_CJK_CHARS",
            "P1_BLANKET_SIGNAL",
            "P1_ENTRY_THRESHOLD_SPLIT",
            "P1_ENTRY_EXIT_CONFUSION",
            "P1_PATCHWORK",
            # v1.0.1 신규
            "P1_VERSION_NO_DIFF",
            "P1_SINGLE_ASSET_BOOST",
            "P1_DEAD_SOURCE",
        ],
        "fail_on":            ["P0", "P1"],
        "baseline_limit":     50,
        "bongyuk_limit":      20,
        "decisive_limit":     20,
        "doc_baseline_relax": True,
    },

    # ═════════════════════════════════════════════════════════════
    # briefing : prima_briefing.py
    # ═════════════════════════════════════════════════════════════
    "briefing": {
        "name":          "briefing",
        "description":   "prima_briefing.py — banned phrases + Crown 매핑",
        "enabled_rules": [
            "P0_BANNED_TERMS",
            "P0_CJK_CHARS",
            "P1_BLANKET_SIGNAL",
            "P1_PATCHWORK",
        ],
        "fail_on":            ["P0", "P1"],
        "baseline_limit":     100,  # briefing 코드 baseline 단어 매우 다수
        "bongyuk_limit":      40,
        "decisive_limit":     30,
        "doc_baseline_relax": True,
    },

    # ═════════════════════════════════════════════════════════════
    # ssot : SSOT 결정문
    # ═════════════════════════════════════════════════════════════
    "ssot": {
        "name":          "ssot",
        "description":   "SSOT 결정문 — baseline 4-case 허용 (SSOT v1.10.178 자기 인정)",
        "enabled_rules": [
            "P0_BANNED_TERMS",
            "P0_CJK_CHARS",
            "P1_CROWN_CLOSED",
            "P1_SIGNAL_CAPITAL_BAD",
            "P1_QUANTITATIVE_MISSING",
            "P1_TIME_DEFERRAL",
            "P1_PATCHWORK",
        ],
        "fail_on":            ["P0", "P1"],
        "baseline_limit":     30,  # SSOT 문서 baseline 다수 인용
        "bongyuk_limit":      15,
        "decisive_limit":     15,
        "doc_baseline_relax": True,
    },

    # ═════════════════════════════════════════════════════════════
    # handoff : 세션 handoff 문서
    # ═════════════════════════════════════════════════════════════
    "handoff": {
        "name":          "handoff",
        "description":   "세션 handoff — Style + 시간 지연 + 결론 우선",
        "enabled_rules": [
            "P0_BANNED_TERMS",
            "P0_CJK_CHARS",
            "P1_BASELINE_OVERUSE",
            "P1_BONGYUK_OVERUSE",
            "P1_DECISIVE_OVERUSE",
            "P1_TIME_DEFERRAL",
            "P1_PATCHWORK",
            "P2_CONCLUSION_FIRST_MISSING",
        ],
        "fail_on":            ["P0", "P1"],
        "baseline_limit":     10,
        "bongyuk_limit":      5,
        "decisive_limit":     5,
        "doc_baseline_relax": True,
    },
}
