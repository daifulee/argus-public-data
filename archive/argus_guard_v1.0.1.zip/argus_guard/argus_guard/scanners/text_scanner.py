# 🦅 ARGUS Guard - TextScanner
# argus_guard:exempt-all
#
# 검사 영역:
#   P0 - 금지어 3종 (본질/결정적/정합 baseline)
#   P0 - 한자 검출
#   P1 - baseline/본격/결정적 카운트 초과
#   P2 - LIVE 값 🌟 ** ** 🌟 wrapping 누락
#   P2 - 약어 풀이 누락
#   P2 - 예상 소요 표시 누락
#   P2 - 결론 우선 마커 누락
#   P3 - 텍스트 번호 목록
#   P3 - HTML 태그

import re
from typing import List, Optional, Iterator

from ..rules import (
    BANNED_TERMS,
    CJK_PATTERN,
    REPLACEMENT_MAP,
    LIVE_VALUE_CANDIDATE_PATTERN,
    LIVE_VALUE_WRAPPED_PATTERN,
    ABBREVIATION_DEFINITIONS,
    CONCLUSION_FIRST_REQUIRED_MARKERS,
    TIME_ESTIMATE_PATTERN,
    NUMBERED_LIST_PATTERN,
    HTML_TAG_PATTERN,
    RULES_REGISTRY,
)


def _line_col(text: str, pos: int) -> tuple:
    """문자열 position → (line, column) 변환 (1-indexed)."""
    line = text.count("\n", 0, pos) + 1
    last_nl = text.rfind("\n", 0, pos)
    col = pos - last_nl if last_nl != -1 else pos + 1
    return line, col


class TextScanner:
    """대화 응답 / 일반 텍스트 검사."""

    def __init__(self, profile: dict):
        self.profile = profile
        self.enabled = set(profile.get("enabled_rules", []))

    # ─────────────────────────────────────────────────────────────
    def scan(self, text: str, file_path: Optional[str] = None):
        """텍스트 전체 검사 — Violation generator."""
        # Violation는 import 순환 회피 위해 함수 내 import
        from ..core import Violation

        # ──────── P0: 금지어 3종 ────────
        if "P0_BANNED_TERMS" in self.enabled:
            for term in BANNED_TERMS:
                for m in re.finditer(re.escape(term), text):
                    line, col = _line_col(text, m.start())
                    yield Violation(
                        rule_id    = "P0_BANNED_TERMS",
                        severity   = "P0",
                        domain     = "style_v12",
                        file       = file_path,
                        line       = line,
                        column     = col,
                        snippet    = term,
                        message    = f"🚨 Style v1.2 금지어 3종 발견: '{term}'",
                        suggestion = f"대체어: {REPLACEMENT_MAP.get(term, '핵심/주요/중요/유의미')}",
                        axiom      = RULES_REGISTRY["P0_BANNED_TERMS"]["axiom"],
                    )

        # ──────── P0: 한자 검출 ────────
        if "P0_CJK_CHARS" in self.enabled:
            for m in CJK_PATTERN.finditer(text):
                line, col = _line_col(text, m.start())
                yield Violation(
                    rule_id    = "P0_CJK_CHARS",
                    severity   = "P0",
                    domain     = "language",
                    file       = file_path,
                    line       = line,
                    column     = col,
                    snippet    = m.group(0),
                    message    = f"🚨 한자 발견: '{m.group(0)}' (U+{ord(m.group(0)):04X})",
                    suggestion = "한국어 또는 표준 한자어로 치환",
                    axiom      = "userPreferences (한국어 원칙)",
                )

        # ──────── P1: Style v1.2 카운트 초과 ────────
        # baseline/본격/결정적 각각 카운트 (단어 경계 인식)
        for word, limit_key, rule_id in (
            ("baseline", "baseline_limit", "P1_BASELINE_OVERUSE"),
            ("본격",     "bongyuk_limit",  "P1_BONGYUK_OVERUSE"),
            ("결정적",   "decisive_limit", "P1_DECISIVE_OVERUSE"),
        ):
            if rule_id not in self.enabled:
                continue
            # 단어 경계 기반 검색
            if word == "baseline":
                # 영문 단어 경계
                matches = list(re.finditer(r"\bbaseline\b", text, re.IGNORECASE))
            else:
                # 한국어 (단어 경계 약함) → 직접 매칭
                matches = list(re.finditer(re.escape(word), text))
            count = len(matches)
            limit = self.profile.get(limit_key, 5)
            if count > limit:
                # 초과 영역 마지막 매칭 위치 보고
                last_m = matches[-1]
                line, col = _line_col(text, last_m.start())
                yield Violation(
                    rule_id    = rule_id,
                    severity   = "P1",
                    domain     = "style_v12",
                    file       = file_path,
                    line       = line,
                    column     = col,
                    snippet    = f"'{word}' x {count}회 (limit={limit})",
                    message    = f"🚨 Style v1.2 위반: '{word}' {count}회 사용 (한계 {limit})",
                    suggestion = f"대체어 사용: {REPLACEMENT_MAP.get(word, '핵심/주요/중요')}",
                    axiom      = RULES_REGISTRY[rule_id]["axiom"],
                )

        # ──────── P2: LIVE 값 🌟 ** ** 🌟 wrapping 누락 ────────
        if "P2_LIVE_VALUE_UNWRAPPED" in self.enabled:
            yield from self._scan_live_value_wrapping(text, file_path)

        # ──────── P2: 약어 풀이 누락 ────────
        if "P2_ABBREVIATION_UNDEFINED" in self.enabled:
            yield from self._scan_abbreviation(text, file_path)

        # ──────── P2: 예상 소요 표시 누락 ────────
        if "P2_TIME_ESTIMATE_MISSING" in self.enabled:
            yield from self._scan_time_estimate(text, file_path)

        # ──────── P2: 결론 우선 마커 누락 ────────
        if "P2_CONCLUSION_FIRST_MISSING" in self.enabled:
            yield from self._scan_conclusion_first(text, file_path)

        # ──────── P3: 텍스트 번호 목록 ────────
        if "P3_NUMBERED_LIST" in self.enabled:
            yield from self._scan_numbered_list(text, file_path)

        # ──────── P3: HTML 태그 ────────
        if "P3_HTML_TAG" in self.enabled:
            yield from self._scan_html_tag(text, file_path)

    # ─────────────────────────────────────────────────────────────
    def _scan_live_value_wrapping(self, text: str, file_path: Optional[str]):
        """LIVE 값 후보 영역에서 🌟 ** ** 🌟 wrapping 검증."""
        from ..core import Violation

        wrapped_spans = [(m.start(), m.end()) for m in LIVE_VALUE_WRAPPED_PATTERN.finditer(text)]

        def is_wrapped(pos: int) -> bool:
            for s, e in wrapped_spans:
                if s <= pos <= e:
                    return True
            return False

        # LIVE 값 후보 검색
        candidates = list(LIVE_VALUE_CANDIDATE_PATTERN.finditer(text))
        unwrapped_count = 0
        for m in candidates:
            if is_wrapped(m.start()):
                continue
            # 표나 코드블록 안은 제외 (간단 휴리스틱)
            line_start = text.rfind("\n", 0, m.start()) + 1
            line_end = text.find("\n", m.start())
            line_text = text[line_start:line_end if line_end != -1 else None]
            if line_text.strip().startswith(("|", "```", "    ", "#")):
                continue
            unwrapped_count += 1
            if unwrapped_count > 3:
                # 너무 많이 보고하지 말 것 (최초 3건만)
                break
            line, col = _line_col(text, m.start())
            yield Violation(
                rule_id    = "P2_LIVE_VALUE_UNWRAPPED",
                severity   = "P2",
                domain     = "preferences",
                file       = file_path,
                line       = line,
                column     = col,
                snippet    = m.group(0),
                message    = f"⚠️ LIVE 값 후보 wrapping 누락: '{m.group(0)}'",
                suggestion = f"🌟 **{m.group(0)}** 🌟 형식으로 wrapping",
                axiom      = "userPreferences",
            )

    # ─────────────────────────────────────────────────────────────
    def _scan_abbreviation(self, text: str, file_path: Optional[str]):
        """약어 첫 등장 시 풀이 검증."""
        from ..core import Violation

        for abbr, definition in ABBREVIATION_DEFINITIONS.items():
            # 약어 첫 등장 위치 검색
            pattern = re.compile(rf"\b{re.escape(abbr)}\b")
            m = pattern.search(text)
            if not m:
                continue
            # 풀이 형식 검사 — "BT (Backtest)" / "BT = Backtest" / "BT: Backtest"
            after = text[m.end():m.end() + 100]
            # 정의 키워드 (첫 단어 또는 일부)
            def_first_word = definition.split()[0]
            has_def_after = (
                def_first_word in after
                or re.search(rf"[\(\[\:=]\s*{re.escape(def_first_word)}", after)
            )
            # 또는 텍스트 전체 어디서든 풀이 있는지 검사
            has_def_anywhere = def_first_word in text
            if not has_def_after and not has_def_anywhere:
                line, col = _line_col(text, m.start())
                yield Violation(
                    rule_id    = "P2_ABBREVIATION_UNDEFINED",
                    severity   = "P2",
                    domain     = "preferences",
                    file       = file_path,
                    line       = line,
                    column     = col,
                    snippet    = abbr,
                    message    = f"⚠️ 약어 풀이 누락: '{abbr}' (= {definition})",
                    suggestion = f"첫 등장 시 '{abbr} ({definition})' 형식 권장",
                    axiom      = "userPreferences",
                )

    # ─────────────────────────────────────────────────────────────
    def _scan_time_estimate(self, text: str, file_path: Optional[str]):
        """예상 소요 표시 검증."""
        from ..core import Violation

        # 응답 텍스트가 충분히 큰 경우에만 검사 (짧은 답변 제외)
        if len(text) < 500:
            return
        if TIME_ESTIMATE_PATTERN.search(text):
            return
        # 첫 줄 위치
        yield Violation(
            rule_id    = "P2_TIME_ESTIMATE_MISSING",
            severity   = "P2",
            domain     = "preferences",
            file       = file_path,
            line       = 1,
            column     = 1,
            snippet    = "(missing)",
            message    = "⚠️ 예상 소요 표시 누락 (응답 길이 500자+)",
            suggestion = "응답 첫 줄에 '⏱️ 약 N분' 형식 권장",
            axiom      = "userPreferences",
        )

    # ─────────────────────────────────────────────────────────────
    def _scan_conclusion_first(self, text: str, file_path: Optional[str]):
        """결론 우선 마커 검증."""
        from ..core import Violation

        if len(text) < 500:
            return
        # 처음 200자 영역에 마커 있는지 검사
        head = text[:500]
        if any(marker in head for marker in CONCLUSION_FIRST_REQUIRED_MARKERS):
            return
        yield Violation(
            rule_id    = "P2_CONCLUSION_FIRST_MISSING",
            severity   = "P2",
            domain     = "preferences",
            file       = file_path,
            line       = 1,
            column     = 1,
            snippet    = "(missing)",
            message    = "⚠️ 결론 우선 마커 누락 (응답 첫 500자 내 '🎯 결론' 부재)",
            suggestion = "응답 첫 단락에 '🎯 결론 우선:' 또는 '🎯 결산' 권장",
            axiom      = "userPreferences",
        )

    # ─────────────────────────────────────────────────────────────
    def _scan_numbered_list(self, text: str, file_path: Optional[str]):
        """텍스트 번호 목록 (1. 2. 3.) 검출."""
        from ..core import Violation

        for m in NUMBERED_LIST_PATTERN.finditer(text):
            # 표 내부 (| 1. |) 또는 코드블록 내부 제외
            line_start = text.rfind("\n", 0, m.start()) + 1
            line_end = text.find("\n", m.start())
            line_text = text[line_start:line_end if line_end != -1 else None]
            if line_text.strip().startswith(("|", "```", "    ")):
                continue
            line, col = _line_col(text, m.start())
            yield Violation(
                rule_id    = "P3_NUMBERED_LIST",
                severity   = "P3",
                domain     = "preferences",
                file       = file_path,
                line       = line,
                column     = col,
                snippet    = line_text.strip()[:60],
                message    = "⚠️ 텍스트 번호 목록 사용 (userPreferences 금지)",
                suggestion = "표 또는 마크다운 헤더로 치환",
                axiom      = "userPreferences",
            )

    # ─────────────────────────────────────────────────────────────
    def _scan_html_tag(self, text: str, file_path: Optional[str]):
        """HTML 태그 검출."""
        from ..core import Violation

        for m in HTML_TAG_PATTERN.finditer(text):
            line, col = _line_col(text, m.start())
            yield Violation(
                rule_id    = "P3_HTML_TAG",
                severity   = "P3",
                domain     = "preferences",
                file       = file_path,
                line       = line,
                column     = col,
                snippet    = m.group(0),
                message    = f"⚠️ HTML 태그 사용: '{m.group(0)}'",
                suggestion = "마크다운 또는 bold+이모지로 치환",
                axiom      = "userPreferences",
            )
