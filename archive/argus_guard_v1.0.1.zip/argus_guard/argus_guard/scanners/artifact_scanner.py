# 🦅 ARGUS Guard - ArtifactScanner
# argus_guard:exempt-all
#
# 파일/디렉토리 메타 영역 검사:
#   P1 - ENTRY_THRESHOLD dict vs hard-coded 'return s > N' 분리 (Crown #65 NO-GO 영구 회피)
#   P1 - 엔진 파일 grep `def _wk` 의무 검증
#   P1 - 파일 헤더 sha256/version 정합 (briefing 영역)

import re
from pathlib import Path
from typing import Optional

from ..rules import (
    ENTRY_THRESHOLD_DICT_PATTERN,
    HARDCODED_RETURN_PATTERN,
    RULES_REGISTRY,
)


def _line_col(text: str, pos: int) -> tuple:
    line = text.count("\n", 0, pos) + 1
    last_nl = text.rfind("\n", 0, pos)
    col = pos - last_nl if last_nl != -1 else pos + 1
    return line, col


class ArtifactScanner:
    """파일 영역 검사 — 엔진 코드 + 메타."""

    def __init__(self, profile: dict):
        self.profile = profile
        self.enabled = set(profile.get("enabled_rules", []))

    # ─────────────────────────────────────────────────────────────
    def scan(self, text: str, file_path: Path):
        """파일 텍스트 + 경로 영역 검사."""
        from ..core import Violation

        # 엔진 .py 파일에만 적용되는 룰
        is_engine = file_path.suffix.lower() == ".py" and (
            "PRIMA" in file_path.name.upper()
            or "ENGINE" in file_path.name.upper()
            or "entry_" in text
            or "exit_" in text
        )

        # ──────── P1: ENTRY_THRESHOLD split (Crown #65 NO-GO 영구 회피) ────────
        if "P1_ENTRY_THRESHOLD_SPLIT" in self.enabled and is_engine:
            yield from self._scan_entry_threshold_split(text, file_path)

    # ─────────────────────────────────────────────────────────────
    def scan_meta(self, file_path: Path):
        """텍스트 디코딩 불가 파일 메타 영역 검사 (현재 noop)."""
        # 향후 binary 파일 sha256 등록 등으로 확장 가능
        return
        yield  # generator 형식 유지

    # ─────────────────────────────────────────────────────────────
    def _scan_entry_threshold_split(self, text: str, file_path: Path):
        """§35.NEW_11 — ENTRY_THRESHOLD dict vs hard-coded return s > N 분리 영구 회피."""
        from ..core import Violation

        has_dict = bool(ENTRY_THRESHOLD_DICT_PATTERN.search(text))
        if not has_dict:
            return  # ENTRY_THRESHOLD dict 부재 → 본 룰 적용 안 함

        # hard-coded return s > N 검색
        hardcoded_matches = list(HARDCODED_RETURN_PATTERN.finditer(text))
        if not hardcoded_matches:
            return  # 모두 dict 정합 → PASS

        # 분리 영역 발견 → P1 보고
        for m in hardcoded_matches[:5]:  # 최초 5건만 보고
            line, col = _line_col(text, m.start())
            yield Violation(
                rule_id    = "P1_ENTRY_THRESHOLD_SPLIT",
                severity   = "P1",
                domain     = "engine",
                file       = str(file_path),
                line       = line,
                column     = col,
                snippet    = m.group(0),
                message    = "🚨 ENTRY_THRESHOLD dict 사용 中 hard-coded 'return s > N' 잔존 (Crown #65 NO-GO 원인 재현 위험)",
                suggestion = "전 ticker 'return s > ENTRY_THRESHOLD[ticker]' 일괄 치환 + validate_entry_threshold_binding() 호출",
                axiom      = RULES_REGISTRY["P1_ENTRY_THRESHOLD_SPLIT"]["axiom"],
            )
