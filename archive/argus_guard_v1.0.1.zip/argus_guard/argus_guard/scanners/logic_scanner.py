# 🦅 ARGUS Guard - LogicScanner
# argus_guard:exempt-all
#
# 검사 영역 (P1 위주):
#   P1 - Crown 닫힌 표현
#   P1 - Signal/Capital 혼동 (alpha 0 → NO-GO 단일 차원)
#   P1 - NO-GO 결정 前 9-point checklist 누락
#   P1 - Top5 참여 편향 8 항목 점검 누락
#   P1 - 평균값 단독 결론
#   P1 - Phase A 단독 평가
#   P1 - 정량 근거 없는 거부
#   P1 - 시간 지연 / 다음 세션 미루기
#   P1 - 블랭킷 시그널
#   P1 - 내부 BT 단독 → Crown 채택
#   P1 - entry/exit threshold 혼동
#   P1 - 미봉책 표현
#   P1 - era 분기 측정 누락

import re
from typing import Optional, List

from ..rules import (
    NO_GO_TRIGGER_TERMS,
    NINE_POINT_REQUIRED_KEYWORDS,
    NINE_POINT_DESCRIPTIONS,
    TOP5_BIAS_8_ITEMS,
    TOP5_BIAS_TRIGGER_TERMS,
    CROWN_CLOSED_PATTERNS,
    SIGNAL_CAPITAL_BAD_PATTERNS,
    AVERAGE_ONLY_BAD_PATTERNS,
    PHASE_A_ONLY_BAD_PATTERNS,
    QUANTITATIVE_EVIDENCE_REQUIRED_TRIGGERS,
    QUANTITATIVE_EVIDENCE_PATTERNS,
    TIME_DEFERRAL_BAD_PATTERNS,
    BLANKET_SIGNAL_BAD_PATTERNS,
    INTERNAL_BT_ONLY_BAD_PATTERNS,
    ENTRY_EXIT_CONFUSION_PATTERNS,
    PATCHWORK_BAD_PATTERNS,
    ERA_CONDITIONAL_TRIGGER_PATTERNS,
    CAPITAL_LEVELS,
    RULES_REGISTRY,
    # v1.0.1 추가
    DATA_FABRICATION_BAD_PATTERNS,
    DATA_FABRICATION_ALLOWED_PATTERNS,
    BUNDLE_SPLIT_BAD_PATTERNS,
    AXIOM_REFERENCE_PATTERN,
    AXIOM_OVERUSE_LIMIT,
    VERSION_CHANGE_TRIGGERS,
    V_DIFF_PATTERNS,
    ENTRY_DECISION_TRIGGERS,
    EXSN_EVALUATION_PATTERNS,
    SINGLE_ASSET_BOOST_TRIGGERS,
    SINGLE_ASSET_BOOST_REQUIRED_VERIFICATIONS,
    DEAD_SOURCE_BAD_PATTERNS,
    CLAUDE_DECISION_TRIGGERS,
    COMMANDER_AUTHORITY_PATTERNS,
)


def _line_col(text: str, pos: int) -> tuple:
    line = text.count("\n", 0, pos) + 1
    last_nl = text.rfind("\n", 0, pos)
    col = pos - last_nl if last_nl != -1 else pos + 1
    return line, col


def _has_any(text: str, keywords: List[str], case_sensitive: bool = False) -> bool:
    if case_sensitive:
        return any(k in text for k in keywords)
    text_low = text.lower()
    return any(k.lower() in text_low for k in keywords)


class LogicScanner:
    """판단 구조 검사 — 광범위 포괄."""

    def __init__(self, profile: dict):
        self.profile = profile
        self.enabled = set(profile.get("enabled_rules", []))

    def scan(self, text: str, file_path: Optional[str] = None):
        from ..core import Violation

        # ──────── P1: Crown 닫힌 표현 ────────
        if "P1_CROWN_CLOSED" in self.enabled:
            for pat, msg in CROWN_CLOSED_PATTERNS:
                for m in pat.finditer(text):
                    line, col = _line_col(text, m.start())
                    yield Violation(
                        rule_id    = "P1_CROWN_CLOSED",
                        severity   = "P1",
                        domain     = "logic",
                        file       = file_path,
                        line       = line,
                        column     = col,
                        snippet    = m.group(0),
                        message    = f"🚨 {msg}",
                        suggestion = "Crown #N LIVE baseline 영구 유지 / 후보 거부 (CANDIDATE 상태 유지, LIVE 미진입) / Signal Layer 보존 (Capital Level 1) / 다음 cycle 재검토 baseline 보존",
                        axiom      = RULES_REGISTRY["P1_CROWN_CLOSED"]["axiom"],
                    )

        # ──────── P1: Signal/Capital 혼동 ────────
        if "P1_SIGNAL_CAPITAL_BAD" in self.enabled:
            for pat, msg in SIGNAL_CAPITAL_BAD_PATTERNS:
                for m in pat.finditer(text):
                    line, col = _line_col(text, m.start())
                    yield Violation(
                        rule_id    = "P1_SIGNAL_CAPITAL_BAD",
                        severity   = "P1",
                        domain     = "logic",
                        file       = file_path,
                        line       = line,
                        column     = col,
                        snippet    = m.group(0)[:80],
                        message    = f"🚨 {msg}",
                        suggestion = "5 Layer 분리 판정 의무: Signal Layer / Regime Tag / Monitoring / Research Registry / Capital Allocation",
                        axiom      = RULES_REGISTRY["P1_SIGNAL_CAPITAL_BAD"]["axiom"],
                    )

        # ──────── P1: NO-GO 결정 前 9-point checklist 누락 ────────
        if "P1_NO_GO_9POINT_MISSING" in self.enabled:
            yield from self._scan_9point(text, file_path)

        # ──────── P1: Top5 참여 편향 8 항목 ────────
        if "P1_PARTICIPATION_BIAS" in self.enabled:
            yield from self._scan_top5_bias(text, file_path)

        # ──────── P1: 평균값 단독 결론 ────────
        if "P1_AVERAGE_ONLY" in self.enabled:
            for pat, msg in AVERAGE_ONLY_BAD_PATTERNS:
                for m in pat.finditer(text):
                    line, col = _line_col(text, m.start())
                    yield Violation(
                        rule_id    = "P1_AVERAGE_ONLY",
                        severity   = "P1",
                        domain     = "logic",
                        file       = file_path,
                        line       = line,
                        column     = col,
                        snippet    = m.group(0)[:80],
                        message    = f"🚨 {msg}",
                        suggestion = "분포 9 항목 동시 보고: 평균/중앙값/std/25%/75%/min/max/Δ>0%/std-mean ratio",
                        axiom      = RULES_REGISTRY["P1_AVERAGE_ONLY"]["axiom"],
                    )

        # ──────── P1: Phase A 단독 평가 ────────
        if "P1_PHASE_A_ONLY" in self.enabled:
            for pat, msg in PHASE_A_ONLY_BAD_PATTERNS:
                for m in pat.finditer(text):
                    line, col = _line_col(text, m.start())
                    yield Violation(
                        rule_id    = "P1_PHASE_A_ONLY",
                        severity   = "P1",
                        domain     = "logic",
                        file       = file_path,
                        line       = line,
                        column     = col,
                        snippet    = m.group(0)[:80],
                        message    = f"🚨 {msg}",
                        suggestion = "§B.9 slot 사전 검증 + Phase B-6 격리 시뮬 의무 (격언 #117 양방향)",
                        axiom      = RULES_REGISTRY["P1_PHASE_A_ONLY"]["axiom"],
                    )

        # ──────── P1: 정량 근거 없는 거부 ────────
        if "P1_QUANTITATIVE_MISSING" in self.enabled:
            yield from self._scan_quantitative_evidence(text, file_path)

        # ──────── P1: 시간 지연 ────────
        if "P1_TIME_DEFERRAL" in self.enabled:
            for pat, msg in TIME_DEFERRAL_BAD_PATTERNS:
                for m in pat.finditer(text):
                    line, col = _line_col(text, m.start())
                    yield Violation(
                        rule_id    = "P1_TIME_DEFERRAL",
                        severity   = "P1",
                        domain     = "evidence",
                        file       = file_path,
                        line       = line,
                        column     = col,
                        snippet    = m.group(0),
                        message    = f"🚨 {msg}",
                        suggestion = "본 cycle 결정 의무 (시간 지연 = 기만 차단 5조 #4 위반)",
                        axiom      = RULES_REGISTRY["P1_TIME_DEFERRAL"]["axiom"],
                    )

        # ──────── P1: 블랭킷 시그널 ────────
        if "P1_BLANKET_SIGNAL" in self.enabled:
            for pat, msg in BLANKET_SIGNAL_BAD_PATTERNS:
                for m in pat.finditer(text):
                    line, col = _line_col(text, m.start())
                    yield Violation(
                        rule_id    = "P1_BLANKET_SIGNAL",
                        severity   = "P1",
                        domain     = "engine",
                        file       = file_path,
                        line       = line,
                        column     = col,
                        snippet    = m.group(0),
                        message    = f"🚨 {msg}",
                        suggestion = "ticker별 _wk_xxx 분리 + grep `def _wk` 검증 의무",
                        axiom      = RULES_REGISTRY["P1_BLANKET_SIGNAL"]["axiom"],
                    )

        # ──────── P1: 내부 BT 단독 → Crown 채택 ────────
        if "P1_INTERNAL_BT_ONLY" in self.enabled:
            for pat, msg in INTERNAL_BT_ONLY_BAD_PATTERNS:
                for m in pat.finditer(text):
                    line, col = _line_col(text, m.start())
                    yield Violation(
                        rule_id    = "P1_INTERNAL_BT_ONLY",
                        severity   = "P1",
                        domain     = "engine",
                        file       = file_path,
                        line       = line,
                        column     = col,
                        snippet    = m.group(0)[:80],
                        message    = f"🚨 {msg}",
                        suggestion = "외부 FA cold audit 의무 (Crown #65 NO-GO 재현 회피)",
                        axiom      = RULES_REGISTRY["P1_INTERNAL_BT_ONLY"]["axiom"],
                    )

        # ──────── P1: entry/exit threshold 혼동 ────────
        if "P1_ENTRY_EXIT_CONFUSION" in self.enabled:
            for pat, msg in ENTRY_EXIT_CONFUSION_PATTERNS:
                for m in pat.finditer(text):
                    line, col = _line_col(text, m.start())
                    yield Violation(
                        rule_id    = "P1_ENTRY_EXIT_CONFUSION",
                        severity   = "P1",
                        domain     = "engine",
                        file       = file_path,
                        line       = line,
                        column     = col,
                        snippet    = m.group(0)[:80],
                        message    = f"🚨 {msg}",
                        suggestion = "entry block ≠ exit 청산 정보 구조 분리 (격언 #79)",
                        axiom      = RULES_REGISTRY["P1_ENTRY_EXIT_CONFUSION"]["axiom"],
                    )

        # ──────── P1: 미봉책 ────────
        if "P1_PATCHWORK" in self.enabled:
            for pat, msg in PATCHWORK_BAD_PATTERNS:
                for m in pat.finditer(text):
                    line, col = _line_col(text, m.start())
                    yield Violation(
                        rule_id    = "P1_PATCHWORK",
                        severity   = "P1",
                        domain     = "logic",
                        file       = file_path,
                        line       = line,
                        column     = col,
                        snippet    = m.group(0),
                        message    = f"🚨 {msg}",
                        suggestion = "근본 처방 (§40 v3 BT 의무 / RULE 29 v2 / 격언 #106)",
                        axiom      = RULES_REGISTRY["P1_PATCHWORK"]["axiom"],
                    )

        # ──────── P1: era 분기 측정 누락 ────────
        if "P1_ERA_CONDITIONAL_MISSING" in self.enabled:
            yield from self._scan_era_conditional(text, file_path)

        # ══════════════════════════════════════════════════════════
        # v1.0.1 추가 룰
        # ══════════════════════════════════════════════════════════

        # ──────── P1: 데이터 위조 (추정값 미명시) ────────
        if "P1_DATA_FABRICATION" in self.enabled:
            yield from self._scan_data_fabrication(text, file_path)

        # ──────── P1: 묶음 작업 분리 ────────
        if "P1_BUNDLE_SPLIT" in self.enabled:
            for pat, msg in BUNDLE_SPLIT_BAD_PATTERNS:
                for m in pat.finditer(text):
                    line, col = _line_col(text, m.start())
                    yield Violation(
                        rule_id    = "P1_BUNDLE_SPLIT",
                        severity   = "P1",
                        domain     = "logic",
                        file       = file_path,
                        line       = line,
                        column     = col,
                        snippet    = m.group(0),
                        message    = f"🚨 {msg}",
                        suggestion = "통합 결정문으로 단일 응답 출력 (운영 SSOT ①)",
                        axiom      = RULES_REGISTRY["P1_BUNDLE_SPLIT"]["axiom"],
                    )

        # ──────── P1: 격언 인용 ≤5건 초과 ────────
        if "P1_AXIOM_OVERUSE" in self.enabled:
            yield from self._scan_axiom_overuse(text, file_path)

        # ──────── P1: 버전 변경 시 V-Diff 누락 ────────
        if "P1_VERSION_NO_DIFF" in self.enabled:
            yield from self._scan_version_diff(text, file_path)

        # ──────── P1: ExSn 사전 평가 누락 ────────
        if "P1_EXSN_PREEVAL_MISSING" in self.enabled:
            yield from self._scan_exsn_preeval(text, file_path)

        # ──────── P1: 단일 자산 boost 위험 ────────
        if "P1_SINGLE_ASSET_BOOST" in self.enabled:
            yield from self._scan_single_asset_boost(text, file_path)

        # ──────── P1: dead source 사용 ────────
        if "P1_DEAD_SOURCE" in self.enabled:
            for pat, msg in DEAD_SOURCE_BAD_PATTERNS:
                for m in pat.finditer(text):
                    line, col = _line_col(text, m.start())
                    yield Violation(
                        rule_id    = "P1_DEAD_SOURCE",
                        severity   = "P1",
                        domain     = "engine",
                        file       = file_path,
                        line       = line,
                        column     = col,
                        snippet    = m.group(0),
                        message    = f"🚨 {msg}",
                        suggestion = "BT_LONG_v4_complete.csv carry-forward + ffill 단독 source 활용 (격언 #67 v3 정합)",
                        axiom      = RULES_REGISTRY["P1_DEAD_SOURCE"]["axiom"],
                    )

        # ──────── P2: Commander 권한 분리 누락 ────────
        if "P2_COMMANDER_AUTHORITY_MISSING" in self.enabled:
            yield from self._scan_commander_authority(text, file_path)

    # ═════════════════════════════════════════════════════════════
    # v1.0.1 추가 scan 메서드
    # ═════════════════════════════════════════════════════════════

    def _scan_data_fabrication(self, text: str, file_path: Optional[str]):
        """추정값 미명시 검출."""
        from ..core import Violation
        for pat, msg in DATA_FABRICATION_BAD_PATTERNS:
            for m in pat.finditer(text):
                # 합법 표현 영역 (50자 이내) 인접 검사
                window = text[max(0, m.start()-50):m.end()+50]
                if any(allowed.search(window) for allowed in DATA_FABRICATION_ALLOWED_PATTERNS):
                    continue
                line, col = _line_col(text, m.start())
                yield Violation(
                    rule_id    = "P1_DATA_FABRICATION",
                    severity   = "P1",
                    domain     = "evidence",
                    file       = file_path,
                    line       = line,
                    column     = col,
                    snippet    = m.group(0),
                    message    = f"🚨 {msg}",
                    suggestion = "정량 source 명시 / (추정) 표기 / N/A 中 선택. 추측값 직접 사용 금지",
                    axiom      = RULES_REGISTRY["P1_DATA_FABRICATION"]["axiom"],
                )

    def _scan_axiom_overuse(self, text: str, file_path: Optional[str]):
        """격언 인용 ≤5건 초과 검출."""
        from ..core import Violation
        matches = list(AXIOM_REFERENCE_PATTERN.finditer(text))
        # 격언 ID별 중복 제거 (동일 격언 다회 인용 = 1건)
        unique_axioms = set(m.group(0) for m in matches)
        if len(unique_axioms) > AXIOM_OVERUSE_LIMIT:
            last_m = matches[-1]
            line, col = _line_col(text, last_m.start())
            yield Violation(
                rule_id    = "P1_AXIOM_OVERUSE",
                severity   = "P1",
                domain     = "style_v12",
                file       = file_path,
                line       = line,
                column     = col,
                snippet    = f"unique 격언 {len(unique_axioms)}개 인용",
                message    = f"🚨 응답당 격언 인용 ≤{AXIOM_OVERUSE_LIMIT}건 초과 ({len(unique_axioms)}건)",
                suggestion = "본질 ≥85% 정합. 격언 인용 줄이고 본질 위주 응답으로 재작성 (운영 SSOT ③)",
                axiom      = RULES_REGISTRY["P1_AXIOM_OVERUSE"]["axiom"],
            )

    def _scan_version_diff(self, text: str, file_path: Optional[str]):
        """버전 변경 표현 + V-Diff 누락 검출."""
        from ..core import Violation
        version_change_found = False
        first_pos = -1
        for pat in VERSION_CHANGE_TRIGGERS:
            m = pat.search(text)
            if m:
                version_change_found = True
                if first_pos == -1 or m.start() < first_pos:
                    first_pos = m.start()
        if not version_change_found:
            return
        # V-Diff 패턴 검출
        has_diff = any(pat.search(text) for pat in V_DIFF_PATTERNS)
        if has_diff:
            return
        line, col = _line_col(text, first_pos)
        yield Violation(
            rule_id    = "P1_VERSION_NO_DIFF",
            severity   = "P1",
            domain     = "engine",
            file       = file_path,
            line       = line,
            column     = col,
            snippet    = "(version change without V-Diff)",
            message    = "🚨 버전 변경 표현 발견 + V-Diff (➕➖✏️) 누락 = §42 위반",
            suggestion = "전체 diff (➕추가/➖삭제/✏️변경) + 각 항목 정량 근거 + SSOT/REGRET_LOG/메모리 기록 의무",
            axiom      = RULES_REGISTRY["P1_VERSION_NO_DIFF"]["axiom"],
        )

    def _scan_exsn_preeval(self, text: str, file_path: Optional[str]):
        """진입/채택 결정 + ExSn 사전 평가 누락 검출."""
        from ..core import Violation
        decision_pos = -1
        for pat in ENTRY_DECISION_TRIGGERS:
            m = pat.search(text)
            if m:
                if decision_pos == -1 or m.start() < decision_pos:
                    decision_pos = m.start()
        if decision_pos == -1:
            return
        # ExSn 평가 키워드 검출
        has_exsn = any(pat.search(text) for pat in EXSN_EVALUATION_PATTERNS)
        if has_exsn:
            return
        line, col = _line_col(text, decision_pos)
        yield Violation(
            rule_id    = "P1_EXSN_PREEVAL_MISSING",
            severity   = "P1",
            domain     = "logic",
            file       = file_path,
            line       = line,
            column     = col,
            snippet    = "(entry decision without ExSn pre-eval)",
            message    = "🚨 진입/채택 결정 표현 발견 + ExSn 사전 평가 누락 = 격언 #87 위반",
            suggestion = "ExSn 우선순위 매트릭스 + exit condition 의무 사전 측정 (격언 #94)",
            axiom      = RULES_REGISTRY["P1_EXSN_PREEVAL_MISSING"]["axiom"],
        )

    def _scan_single_asset_boost(self, text: str, file_path: Optional[str]):
        """단일 자산 100% boost + 분산 검증 누락."""
        from ..core import Violation
        boost_pos = -1
        for pat in SINGLE_ASSET_BOOST_TRIGGERS:
            m = pat.search(text)
            if m:
                if boost_pos == -1 or m.start() < boost_pos:
                    boost_pos = m.start()
        if boost_pos == -1:
            return
        # 분산/대안 검증 키워드 검출
        text_low = text.lower()
        has_verification = any(
            kw.lower() in text_low
            for kw in SINGLE_ASSET_BOOST_REQUIRED_VERIFICATIONS
        )
        if has_verification:
            return
        line, col = _line_col(text, boost_pos)
        yield Violation(
            rule_id    = "P1_SINGLE_ASSET_BOOST",
            severity   = "P1",
            domain     = "engine",
            file       = file_path,
            line       = line,
            column     = col,
            snippet    = "(single asset boost without diversification check)",
            message    = "🚨 단일 자산 100% / boost 표현 + 분산/대안 검증 누락 = 격언 #112 v2 #9 v2 위반",
            suggestion = "분산 효과 / 대안 자산 비교 / concentration risk 검증 의무",
            axiom      = RULES_REGISTRY["P1_SINGLE_ASSET_BOOST"]["axiom"],
        )

    def _scan_commander_authority(self, text: str, file_path: Optional[str]):
        """Claude 채택 결정 + Commander 권한 분리 누락."""
        from ..core import Violation
        decision_pos = -1
        for pat in CLAUDE_DECISION_TRIGGERS:
            m = pat.search(text)
            if m:
                if decision_pos == -1 or m.start() < decision_pos:
                    decision_pos = m.start()
        if decision_pos == -1:
            return
        # Commander 권한 분리 표현 검출
        has_authority = any(pat.search(text) for pat in COMMANDER_AUTHORITY_PATTERNS)
        if has_authority:
            return
        line, col = _line_col(text, decision_pos)
        yield Violation(
            rule_id    = "P2_COMMANDER_AUTHORITY_MISSING",
            severity   = "P2",
            domain     = "preferences",
            file       = file_path,
            line       = line,
            column     = col,
            snippet    = "(decision without Commander authority note)",
            message    = "⚠️ 채택/승인/확정 표현 발견 + Commander 절대 결정권 분리 누락 = 격언 #15 위반",
            suggestion = "'PRIMA/ARGUS = 권고 only / Commander = 최종 채택 결정' 표현 추가",
            axiom      = RULES_REGISTRY["P2_COMMANDER_AUTHORITY_MISSING"]["axiom"],
        )

    # ─────────────────────────────────────────────────────────────
    def _scan_9point(self, text: str, file_path: Optional[str]):
        """NO-GO 결정 발견 시 9-point checklist 모든 항목 점검 검증."""
        from ..core import Violation

        # NO-GO 트리거 발견 여부
        trigger_hits = []
        for term in NO_GO_TRIGGER_TERMS:
            for m in re.finditer(re.escape(term), text):
                trigger_hits.append((term, m.start()))
        if not trigger_hits:
            return

        # 9-point 각 항목 검증
        missing_points = []
        for pt_num, keywords in NINE_POINT_REQUIRED_KEYWORDS.items():
            if not _has_any(text, keywords):
                missing_points.append(pt_num)

        # 5건 이상 누락 시 P1 보고 (5 中 4 NO → NO-GO 확정 권고 기준 정합)
        if len(missing_points) >= 5:
            first_trigger = trigger_hits[0]
            line, col = _line_col(text, first_trigger[1])
            missing_desc = ", ".join(
                f"Point #{n} ({NINE_POINT_DESCRIPTIONS[n]})" for n in missing_points
            )
            yield Violation(
                rule_id    = "P1_NO_GO_9POINT_MISSING",
                severity   = "P1",
                domain     = "logic",
                file       = file_path,
                line       = line,
                column     = col,
                snippet    = first_trigger[0],
                message    = f"🚨 NO-GO 결정 발견 but 9-point checklist {len(missing_points)}/9 항목 누락: {missing_desc}",
                suggestion = "9point_checklist_detail.md 의무 적용 후 NO-GO 결정 재검토",
                axiom      = RULES_REGISTRY["P1_NO_GO_9POINT_MISSING"]["axiom"],
            )

    # ─────────────────────────────────────────────────────────────
    def _scan_top5_bias(self, text: str, file_path: Optional[str]):
        """Top5 관련 영역에서 8 항목 점검 검증."""
        from ..core import Violation

        if not _has_any(text, TOP5_BIAS_TRIGGER_TERMS):
            return

        # 8 항목 중 누락 항목 검출
        missing_items = []
        for item in TOP5_BIAS_8_ITEMS:
            # 항목명 일부라도 포함되는지
            tokens = item.replace("실제 ", "").replace("평균 ", "").split()
            if not any(tok in text for tok in tokens if len(tok) > 1):
                missing_items.append(item)

        # 4건 이상 누락 시 보고
        if len(missing_items) >= 4:
            yield Violation(
                rule_id    = "P1_PARTICIPATION_BIAS",
                severity   = "P1",
                domain     = "logic",
                file       = file_path,
                line       = 1,
                column     = 1,
                snippet    = f"Top5 관련 영역 - {len(missing_items)}/8 항목 누락",
                message    = f"🚨 Top5 참여 편향 8 항목 미점검: {', '.join(missing_items[:5])}{'...' if len(missing_items) > 5 else ''}",
                suggestion = "격언 #120 v1 — signal ON 일수 / Top5 진입률 / 평균 rank / shadow forward return / hit rate / payoff / participation-adjusted score / portfolio alpha 8 항목 의무",
                axiom      = RULES_REGISTRY["P1_PARTICIPATION_BIAS"]["axiom"],
            )

    # ─────────────────────────────────────────────────────────────
    def _scan_quantitative_evidence(self, text: str, file_path: Optional[str]):
        """거부/NO-GO 결정 발견 시 정량 근거 검증."""
        from ..core import Violation

        # 거부 트리거
        trigger_hits = []
        for term in QUANTITATIVE_EVIDENCE_REQUIRED_TRIGGERS:
            for m in re.finditer(re.escape(term), text):
                trigger_hits.append((term, m.start()))
        if not trigger_hits:
            return

        # 정량 근거 패턴 검출 (전체 텍스트에서)
        quant_found = any(pat.search(text) for pat in QUANTITATIVE_EVIDENCE_PATTERNS)
        if quant_found:
            return

        # 트리거 발견 + 정량 근거 全 부재 → 보고
        first = trigger_hits[0]
        line, col = _line_col(text, first[1])
        yield Violation(
            rule_id    = "P1_QUANTITATIVE_MISSING",
            severity   = "P1",
            domain     = "evidence",
            file       = file_path,
            line       = line,
            column     = col,
            snippet    = first[0],
            message    = "🚨 거부/NO-GO 결정에 정량 근거 부재 (수치/통계/STRESS 등)",
            suggestion = "BT 수치 (CAGR/Sharpe/MDD p점) / t-stat / STRESS N/N / RULE 29 v2 등 정량 증거 첨부 의무",
            axiom      = RULES_REGISTRY["P1_QUANTITATIVE_MISSING"]["axiom"],
        )

    # ─────────────────────────────────────────────────────────────
    def _scan_era_conditional(self, text: str, file_path: Optional[str]):
        """FULL 평균만 사용 → era 분기 측정 누락 검증."""
        from ..core import Violation

        # NO-GO 결정 발견 여부
        has_no_go = _has_any(text, NO_GO_TRIGGER_TERMS)
        if not has_no_go:
            return

        # FULL 평균 인용 발견
        full_only = False
        for pat in ERA_CONDITIONAL_TRIGGER_PATTERNS:
            if pat.search(text):
                full_only = True
                break
        if not full_only:
            return

        # era 분기 키워드 발견 여부
        era_split = any(era in text for era in ("P1", "P2", "P3", "MID"))
        if era_split:
            return  # era 분기 정합

        yield Violation(
            rule_id    = "P1_ERA_CONDITIONAL_MISSING",
            severity   = "P1",
            domain     = "logic",
            file       = file_path,
            line       = 1,
            column     = 1,
            snippet    = "(FULL 평균 only)",
            message    = "🚨 FULL 평균만으로 NO-GO 판정 + era 분기 (P1/P2/P3/MID) 누락",
            suggestion = "§35 #13 + 격언 #119 v2 — era 분기 측정 의무 (Uninvestable Alpha 3 사례 정합)",
            axiom      = RULES_REGISTRY["P1_ERA_CONDITIONAL_MISSING"]["axiom"],
        )
