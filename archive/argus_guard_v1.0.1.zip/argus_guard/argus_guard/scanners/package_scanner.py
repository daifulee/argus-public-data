# 🦅 ARGUS Guard - PackageScanner
# argus_guard:exempt-all
#
# zip 압축 패키지 재귀 검사:
#   - zip 내부 텍스트 파일 추출 → 각각 scan_text + scan_artifact
#   - 위반 누적 → 최종 GuardResult 통합

import hashlib
import zipfile
from pathlib import Path
from typing import Optional

from .text_scanner     import TextScanner
from .logic_scanner    import LogicScanner
from .artifact_scanner import ArtifactScanner


# 텍스트 파일 인식 확장자
TEXT_EXTENSIONS = {
    ".py", ".md", ".txt", ".json", ".yaml", ".yml", ".csv",
    ".rst", ".ini", ".cfg", ".toml", ".sh", ".html",
}


class PackageScanner:
    """zip 압축 패키지 재귀 검사."""

    def __init__(self, profile: dict):
        self.profile = profile
        self.text_scanner     = TextScanner(profile)
        self.logic_scanner    = LogicScanner(profile)
        self.artifact_scanner = ArtifactScanner(profile)

    def scan(self, zip_path: str):
        """zip 파일 검사 → GuardResult."""
        from ..core import GuardResult, Violation

        zp = Path(zip_path)
        if not zp.exists():
            raise FileNotFoundError(f"zip 파일 없음: {zip_path}")
        if not zp.is_file():
            raise ValueError(f"파일 아님: {zip_path}")

        result = GuardResult(target=str(zp))
        result.target_hash = self._sha256_file(zp)

        try:
            zf = zipfile.ZipFile(zp, "r")
        except zipfile.BadZipFile as e:
            result.add(Violation(
                rule_id  = "P1_BAD_ZIP",
                severity = "P1",
                domain   = "package",
                file     = str(zp),
                message  = f"🚨 잘못된 zip 파일: {e}",
                axiom    = "ARGUS Guard PackageScanner",
            ))
            result.finalize(fail_on=self.profile.get("fail_on", ["P0", "P1"]))
            return result

        with zf:
            for name in zf.namelist():
                # 디렉토리 무시
                if name.endswith("/"):
                    continue
                p = Path(name)
                if p.suffix.lower() not in TEXT_EXTENSIONS:
                    continue
                try:
                    raw = zf.read(name)
                    text = raw.decode("utf-8")
                except (UnicodeDecodeError, KeyError):
                    continue
                inner_path = f"{zp.name}::{name}"
                # Text scan
                for v in self.text_scanner.scan(text, file_path=inner_path):
                    result.add(v)
                # Logic scan
                for v in self.logic_scanner.scan(text, file_path=inner_path):
                    result.add(v)
                # Artifact scan (Path 호환 가짜 경로)
                fake_path = Path(name)
                for v in self.artifact_scanner.scan(text, fake_path):
                    # 파일 경로를 zip 내부 경로로 재기록
                    v.file = inner_path
                    result.add(v)

        result.finalize(fail_on=self.profile.get("fail_on", ["P0", "P1"]))
        return result

    @staticmethod
    def _sha256_file(p: Path) -> str:
        h = hashlib.sha256()
        with p.open("rb") as f:
            for chunk in iter(lambda: f.read(65536), b""):
                h.update(chunk)
        return h.hexdigest()
