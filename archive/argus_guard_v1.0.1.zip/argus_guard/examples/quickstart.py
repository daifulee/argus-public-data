# 🦅 ARGUS Guard - Quickstart 예시
# argus_guard:exempt-all
#
# 실행: python examples/quickstart.py

import sys
from pathlib import Path

# argus_guard 모듈 path 추가
sys.path.insert(0, str(Path(__file__).parent.parent))

from argus_guard import Guard


def example_1_response_check():
    """예시 1: 대화 응답 검사 (response 프로필)."""
    print("\n" + "=" * 60)
    print("예시 1: 대화 응답 검사 — response 프로필")
    print("=" * 60)

    bad_text = (
        "본 결정은 본질 baseline에 따라 채택합니다.\n"
        "Top5 0% → 신호 실패. 폐기 처리.\n"
        "다음 세션에 결정.\n"
    )
    g = Guard(profile="response")
    result = g.scan_text(bad_text)
    print(f"status:  {result.status}")
    print(f"summary: {result.summary}")
    for v in result.violations[:5]:
        print(f"  [{v.severity}] {v.rule_id}: {v.message}")


def example_2_reg_check():
    """예시 2: REG 결정문 검사 — 정상 케이스."""
    print("\n" + "=" * 60)
    print("예시 2: REG 결정문 정합 — reg 프로필 PASS 케이스")
    print("=" * 60)

    good_text = (
        "🎯 결론: CAND-S121_β Tier 1 Signal Layer 채택 (Capital Level 1).\n"
        "Phase A α 🌟 **+14.52p** 🌟 / t=🌟 **+4.21** 🌟 정량 근거.\n"
        "Signal Layer: GO / Capital Allocation: 보류 (sleeve cap 필요 없음).\n"
        "분포 평균/중앙값/std/분위 동시 보고.\n"
        "Top5 진입률 0% / 평균 rank 18.5위 / shadow forward return / hit rate / payoff 측정.\n"
        "regime 분기 P1/P2/MID 모두 검증.\n"
        "outlier 진단 + 대상 확장 + 양방향 모두 PASS.\n"
        "sub-group + 대안 자산 + 꼬리 모두 점검.\n"
        "외부 FA cold audit 통과.\n"
        "⏱️ 약 90분 소요.\n"
    )
    g = Guard(profile="reg")
    result = g.scan_text(good_text)
    print(f"status:  {result.status}")
    print(f"summary: {result.summary}")


def example_3_engine_check():
    """예시 3: PRIMA 엔진 코드 검사 (Crown #65 NO-GO 영구 회피)."""
    print("\n" + "=" * 60)
    print("예시 3: PRIMA 엔진 코드 — ENTRY_THRESHOLD split 검출")
    print("=" * 60)

    import tempfile
    import os
    bad_code = (
        "ENTRY_THRESHOLD = {'XLU': 1.5, 'TLT': 1.0}\n\n"
        "def entry_TLT(m, m1, m3):\n"
        "    s = 5.0\n"
        "    return s > 1.0, max(s, 0)  # hard-coded\n"
    )
    with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False, encoding="utf-8") as f:
        f.write(bad_code)
        tmp = f.name
    try:
        g = Guard(profile="engine")
        result = g.scan_file(tmp)
        print(f"status:  {result.status}")
        for v in result.violations:
            if v.rule_id == "P1_ENTRY_THRESHOLD_SPLIT":
                print(f"  [{v.severity}] {v.rule_id}")
                print(f"      message: {v.message}")
                print(f"      suggestion: {v.suggestion}")
    finally:
        os.unlink(tmp)


def example_4_zip_check():
    """예시 4: zip 압축 패키지 재귀 검사."""
    print("\n" + "=" * 60)
    print("예시 4: zip 패키지 — 내부 다중 파일 재귀")
    print("=" * 60)

    import tempfile
    import os
    import zipfile

    with tempfile.NamedTemporaryFile(suffix=".zip", delete=False) as f:
        tmp_zip = f.name
    try:
        with zipfile.ZipFile(tmp_zip, "w") as zf:
            zf.writestr("REG-S122.md", "정합 baseline 채택")  # P0 violation
            zf.writestr("clean.md", "Sharpe +0.123 / CAGR +1.45p")
        g = Guard(profile="default")
        result = g.scan_zip(tmp_zip)
        print(f"status:  {result.status}")
        print(f"summary: {result.summary}")
        for v in result.violations:
            print(f"  [{v.severity}] {v.rule_id}: {v.file}")
    finally:
        os.unlink(tmp_zip)


if __name__ == "__main__":
    example_1_response_check()
    example_2_reg_check()
    example_3_engine_check()
    example_4_zip_check()
    print("\n" + "=" * 60)
    print("🦅 ARGUS Guard quickstart 완료")
    print("=" * 60)
