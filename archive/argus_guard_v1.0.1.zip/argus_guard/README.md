# 🦅 ARGUS Guard v1.0.1

<!-- argus_guard:exempt-all -->
<!-- (본 README는 룰의 패턴 명칭을 그대로 인용하므로 false-positive 회피용 exempt) -->

광범위 포괄 차단형 검증 계층 — ARGUS 운영 반복 실수 영구 회피

**v1.0.1 갱신 (2026-05-19)**: 메모리/격언 누적 §35 누락 사례 8개 추가 룰 통합 → 총 33 룰 / 26 AT PASS

## 🎯 본 패키지의 본질

ARGUS Commander Lignas 영구 명령 + §35 자기 정정 누적 + 격언 #15~#120 v1 + Style Patch v1.2 + userPreferences 통합 차단 계층. 단일 `pip` 의존 없이 표준 라이브러리만으로 즉시 실행.

## 📋 차단 차원 매트릭스 (25 룰 등록)

| 등급 | 룰 | 차단 차원 | 출처 |
|:--:|:--|:--|:--|
| P0 | BANNED_TERMS | 금지어 3종 (본질/결정적/정합 baseline) | Commander 영구 명령 |
| P0 | CJK_CHARS | 한자 검출 | userPreferences |
| P1 | BASELINE/BONGYUK/DECISIVE_OVERUSE | Style v1.2 카운트 초과 | SSOT v1.10.178 |
| P1 | CROWN_CLOSED | Crown 닫힌 표현 ("완전 폐기") | 격언 #74 + #98 |
| P1 | SIGNAL_CAPITAL_BAD | alpha 0 → NO-GO 단일 차원 | §35 #12 + 격언 #118 v3 |
| P1 | NO_GO_9POINT_MISSING | NO-GO 결정 前 9-point 누락 | 격언 #116 |
| P1 | PARTICIPATION_BIAS | Top5 참여 편향 8 항목 미점검 | 격언 #120 v1 |
| P1 | AVERAGE_ONLY | 평균값 단독 결론 | §35 #11 |
| P1 | PHASE_A_ONLY | Phase A 단독 평가 → 결정 | 격언 #25 + #52 + #117 |
| P1 | QUANTITATIVE_MISSING | 정량 근거 없는 거부 | 기만 차단 5조 #3 |
| P1 | TIME_DEFERRAL | 시간 지연 / "다음 세션 결정" | 기만 차단 5조 #4 |
| P1 | BLANKET_SIGNAL | 블랭킷 시그널 ("전종목 즉시 청산") | 격언 #48 + #75 v4 |
| P1 | INTERNAL_BT_ONLY | 내부 BT 단독 → Crown 채택 | 격언 #97 v2 |
| P1 | ENTRY_THRESHOLD_SPLIT | dict vs hard-coded 분리 (엔진 .py) | §35.NEW_11 (Crown #65) |
| P1 | ENTRY_EXIT_CONFUSION | entry/exit threshold 동일 | 격언 #79 |
| P1 | PATCHWORK | 미봉책 표현 (일시 우회 / monkey-patch) | 격언 #56 + #106 |
| P1 | ERA_CONDITIONAL_MISSING | era 분기 누락 (FULL 평균만) | §35 #13 + 격언 #119 v2 |
| P2 | LIVE_VALUE_UNWRAPPED | LIVE 값 🌟 ** ** 🌟 wrapping 누락 | userPreferences |
| P2 | ABBREVIATION_UNDEFINED | 약어 첫 등장 시 풀이 누락 | userPreferences |
| P2 | TIME_ESTIMATE_MISSING | 예상 소요 표시 누락 | userPreferences |
| P2 | CONCLUSION_FIRST_MISSING | 결론 우선 마커 누락 | userPreferences |
| P3 | NUMBERED_LIST | 텍스트 번호 목록 (1. 2. 3.) | userPreferences |
| P3 | HTML_TAG | HTML 태그 사용 | userPreferences |
| **v1.0.1** | | | |
| P1 | DATA_FABRICATION | 추정/추측/임의값 미명시 (N/A 또는 정량 근거 의무) | 불가침 SSOT 5조 ③ |
| P1 | BUNDLE_SPLIT | 결정문 분리 출력 (묶음 작업 의무) | 운영 SSOT ① |
| P1 | AXIOM_OVERUSE | 응답당 격언 인용 >5건 초과 | 운영 SSOT ③ + 격언 #110 |
| P1 | VERSION_NO_DIFF | 버전 변경 시 V-Diff (➕➖✏️) 누락 | §42 + 격언 #16 |
| P1 | EXSN_PREEVAL_MISSING | 진입/채택 결정 + ExSn 사전 평가 누락 | 격언 #87 + #94 |
| P1 | SINGLE_ASSET_BOOST | 단일 자산 boost 위험 미검증 | 격언 #112 v2 #9 v2 |
| P1 | DEAD_SOURCE | dead source (DBnomics PMI 등) 사용 시도 | 격언 #67 v3 + #96 v2 ② |
| P2 | COMMANDER_AUTHORITY_MISSING | Claude 채택 결정 + Commander 권한 분리 누락 | 격언 #15 + 불가침 SSOT ⑤ |

## 🎛️ 프로필 매트릭스 (7종)

| 프로필 | 룰 활성 | baseline 한계 | 적용 영역 |
|:--|--:|--:|:--|
| default | 25 | 5 | 전 영역 (가장 엄격) |
| response | 13 | 5 | 대화 응답 |
| reg | 17 | 8 | REG (Regret Log) 결정문 |
| engine | 6 | 50 | PRIMA 엔진 .py |
| briefing | 4 | 100 | prima_briefing.py |
| ssot | 7 | 30 | SSOT 결정문 |
| handoff | 8 | 10 | 세션 handoff 문서 |

## 🚀 사용법

### CLI

```bash
# 텍스트 (파일 또는 stdin)
python -m argus_guard scan-text response.txt
echo "본질 baseline 채택" | python -m argus_guard scan-text -

# 단일 파일
python -m argus_guard scan-file REG-S122.md --profile reg

# 디렉토리 재귀
python -m argus_guard scan-tree ./outputs --recursive --format markdown

# zip 압축 재귀
python -m argus_guard scan-zip ARGUS_ARCHIVE.zip

# 프로필 / 룰 목록
python -m argus_guard list-profiles
python -m argus_guard list-rules

# 출력 형식 (short / json / markdown)
python -m argus_guard scan-file decision.md --format json
python -m argus_guard scan-file decision.md --format markdown > report.md

# 종료 코드 (CI 통합)
python -m argus_guard scan-file decision.md || echo "FAIL"
```

### Python API

```python
from argus_guard import Guard

g = Guard(profile="reg")

# 텍스트 검사
result = g.scan_text("본질 baseline 채택")
print(result.status)             # 'FAIL'
print(result.summary)            # {'P0': 1, 'P1': 0, ...}
print(result.to_markdown())

# 파일 검사
result = g.scan_file("REG-S122.md")
if result.status == "FAIL":
    for v in result.violations:
        print(f"[{v.severity}] {v.rule_id} {v.file}:L{v.line} - {v.message}")

# zip 검사
result = g.scan_zip("ARGUS_ARCHIVE.zip")
```

## 📦 패키지 구조

```
argus_guard/
├── __init__.py          # 패키지 entry
├── __main__.py          # CLI entry point
├── core.py              # Guard 메인 클래스 + Violation + GuardResult
├── rules.py             # 모든 룰 정의 (~25 등록)
├── profiles.py          # 프로필 매트릭스 (7종)
└── scanners/
    ├── text_scanner.py     # P0/P1 Style v1.2 + P2/P3 userPreferences
    ├── logic_scanner.py    # P1 9point + Top5 + Crown + Signal/Capital 등
    ├── artifact_scanner.py # P1 엔진 ENTRY_THRESHOLD split
    └── package_scanner.py  # zip 재귀

tests/
└── test_guard.py        # 12 Acceptance Test + 통합 테스트
```

## ✅ Acceptance Test (15/15 PASS)

| ID | 검증 |
|:--|:--|
| AT-1 | 금지어 3종 P0 검출 |
| AT-2 | 한자 P0 검출 |
| AT-3 | 정상 한국어 PASS |
| AT-4 | Python 주석 내 금지어 P0 |
| AT-5 | Markdown 표 내 금지어 P0 |
| AT-6 | zip 내부 위반 P0 |
| AT-7 | NO-GO 보고 9point 누락 P1 |
| AT-8 | Signal/Capital 정합 분리 PASS |
| AT-9 | Top5 참여 편향 P1 |
| AT-10 | Crown 닫힌 표현 P1 |
| AT-11 | Style v1.2 카운트 초과 P1 |
| AT-12 | ENTRY_THRESHOLD split P1 |
| INT-1 | 모든 프로필 인스턴스화 |
| INT-2 | 빈 텍스트 PASS |
| INT-3 | JSON / Markdown 형식 출력 |

## 🔗 격언/SSOT 참조

- Commander 영구 명령 (2026-05-19) — 금지어 3종 확정
- Style Patch v1.0/v1.1/v1.2 — SSOT v1.10.142 + v1.10.178
- 격언 #15 (Commander 절대 결정) / #20 (정직 인지) / #25 (Phase A ≠ Phase B) / #48 (블랭킷 차단) / #52 (slot 결정) / #56 (§40 v3 BT 의무) / #74 (Crown 보존) / #75 v4 (ticker별 분리) / #76 (sweep plateau) / #79 (entry vs exit) / #87 (ExSn 사전) / #88 v3 (BT 재현성) / #91 v3 (4 패턴 + Regime Reversal) / #97 v2 (외부 FA 의무) / #98 (재검토 baseline) / #105 (함정 검출) / #106 (근본 처방) / #115 (effective horizon) / #116 (6축 자발) / #117 (양방향 금지) / #118 v3 (5-Tier Capital) / #119 v2 (era-conditional) / #120 v1 (Top5 편향) / #121 (Drive 단일)
- §35 누적 — #10 / #11 / #12 / #13 / .NEW_11 / .26 / .37+38
- 기만 차단 5조 — #1~#5

## 📜 버전

- **v1.0.0** (2026-05-19) — 광범위 포괄 하니스 초판 (Commander 명령)
